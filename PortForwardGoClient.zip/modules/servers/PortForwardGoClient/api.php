<?php
require_once __DIR__ . '/../../../init.php';
require_once __DIR__ . '/../../addons/PortForwardGo/func.php';

use Illuminate\Database\Capsule\Manager as Capsule;

define("WHMCS_API", true);
if (!isset($_REQUEST['id']) || !isset($_REQUEST['token']) || !isset($_REQUEST['action'])) {
    exit(json_encode(['success' => false, 'msg' => 'Missing parameter']));
}

$sql = Capsule::table("mod_PortForwardGo_Users")->where('id', $_REQUEST['id']);
if (!$sql->exists()) {
    exit(json_encode(['success' => false, 'msg' => 'Invalid credentials']));
}

$user = $sql->first();
if ($user->api == 'disabled' || strtolower($_REQUEST['token']) != strtolower(md5($user->api))) {
    exit(json_encode(['success' => false, 'msg' => 'Invalid credentials']));
}

$file = __DIR__ . '/api/' . $_REQUEST['action'] . '.php';
if (!file_exists($file)) {
    exit(json_encode(['success' => false, 'msg' => 'Invalid action']));
}

$data = [];

if (isset($_SERVER['HTTP_CONTENT_TYPE']) && $_SERVER['HTTP_CONTENT_TYPE'] == "application/json") {
    $params = json_decode(file_get_contents("php://input"), true);
} else {
    $params = $_REQUEST;
}
include_once($file);
