<?php
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use Illuminate\Database\Capsule\Manager as Capsule;

require_once(__DIR__ . '/../../../addons/PortForwardGo/func.php');

if (!isset($_REQUEST["id"]) || !isset($_REQUEST["ruleid"])) {
    exit(json_encode(["result" => "error", "error" => "无效请求"]));
}

if (!Capsule::table('mod_PortForwardGo_Users')->where('sid', $_REQUEST['id'])->exists()) {
    exit(json_encode(["result" => "error", "error" => "服务不存在"]));
}

$sql = Capsule::table('mod_PortForwardGo_Rules')->where('sid', $_REQUEST['id'])->where('id', $_REQUEST['ruleid']);
if (!$sql->exists()) {
    exit(json_encode(["result" => "error", "error" => "规则不存在"]));
}
$data = $sql->first();
if ($data->status != "Active") {
    exit(json_encode(["result" => "error", "error" => "权限不足"]));
}
$sql->update(['status' => 'Disabled']);

if (PortForwardGo_APICall($_REQUEST['ruleid'])) {
    exit(json_encode(['result' => 'success', 'msg' => '此规则停用成功']));
} else {
    exit(json_encode(['result' => 'success', 'msg' => '此规则停用成功，将在不久后生效']));
}
