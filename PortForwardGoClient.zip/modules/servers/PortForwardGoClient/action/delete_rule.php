<?php
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use Illuminate\Database\Capsule\Manager as Capsule;

require_once(__DIR__ . '/../../../addons/PortForwardGo/func.php');

if (!isset($_REQUEST["id"]) || !isset($_REQUEST["ruleid"])) {
    exit(json_encode(["result" => "error", "error" => "无效请求"]));
}

$sql = Capsule::table('mod_PortForwardGo_Rules')->where('sid', $params['serviceid'])->where('id', $_REQUEST['ruleid'])->where('status', '!=', 'Deleted');
if (!$sql->exists()) {
    exit(json_encode(["result" => "error", "error" => '规则不存在!']));
}
$data = $sql->first();
if ($data->status == 'Created') {
    if ((bool)$data->rc) {
        Capsule::table("mod_PortForwardGo_RClient_Changes")->where("rule_id", $data->id)->delete();
    }
    $sql->delete();
} else if ($data->status == 'Suspend') {
    exit(json_encode(["result" => "error", "error" => "权限不足"]));
} else {
    $sql->update(['status' => 'Deleted']);
    if ((bool)$data->rc) {
        $sql = Capsule::table("mod_PortForwardGo_RClient_Changes")->where('node', $data->node)->where('rule_id', $data->id);
        if ($sql->exists()) {
            $sql->delete();
        } else {
            Capsule::table("mod_PortForwardGo_RClient_Changes")->insert(['sid' => $data->sid, 'node' => $data->node, 'rule_id' => $data->id, 'status' => 'Deleted']);
        }
    }
    if (PortForwardGo_APICall($_REQUEST['ruleid'])) {
        Capsule::table('mod_PortForwardGo_Rules')->where('sid', $params['serviceid'])->where('id', $_REQUEST['ruleid'])->delete();
    }
}
exit(json_encode(["result" => "success", 'msg' => '转发规则已删除']));
