<?php
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use Illuminate\Database\Capsule\Manager as Capsule;

require_once(__DIR__ . '/../../../addons/PortForwardGo/func.php');

if (!isset($_REQUEST["node"]) || !isset($_REQUEST['cron'])) {
    exit(json_encode(["result" => "error", "error" => "无效请求"]));
}

if ($_REQUEST['cron'] < 120) {
    exit(json_encode(["result" => "error", "error" => "同步时间过快"]));
}

$sql = Capsule::table("mod_PortForwardGo_Node")->where('id', $_REQUEST['node']);
if (!$sql->exists()) {
    exit(json_encode(["result" => "error", "error" => "找不到此节点"]));
}
$data = $sql->first();
if ($data->rc_tcp_port == "0") {
    exit(json_encode(["result" => "error", "error" => "此节点不支持内网穿透"]));
}

if (isset($_REQUEST['download'])) {
    $user = Capsule::table('mod_PortForwardGo_Users')->where('sid', $params['serviceid'])->first();

    $arr = [
        "URL" => PortForwardGo_GetSystemURL() . 'modules/servers/PortForwardGoClient/rclient.php?token=' . base64_encode($user->id . '|' . $user->sid),
        "Cron" => (int)$_REQUEST['cron'],
        "NodeID" => (int)$_REQUEST['node'],
    ];
    $file = json_encode($arr);

    header("Content-type: application/octet-stream");
    header("Accept-Ranges: bytes");
    header("Accept-Length: " . strlen($file));
    header("Content-Disposition: attachment; filename=config.json");
    exit($file);
}

exit(json_encode(["result" => "success", "download_url" => PortForwardGo_GetSystemURL() . 'clientarea.php?action=productdetails&id=' . $_REQUEST['id'] . '&a=export_rclient_config&node=' . $_REQUEST['node'] . '&cron=' . $_REQUEST['cron'] . '&download=yes']));
