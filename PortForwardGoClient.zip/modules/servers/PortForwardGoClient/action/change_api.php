<?php
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use Illuminate\Database\Capsule\Manager as Capsule;

require_once(__DIR__ . '/../../../addons/PortForwardGo/func.php');

if (!isset($_REQUEST["id"]) || !isset($_REQUEST["doing"])) {
    exit(json_encode(["result" => "error", "error" => "无效请求"]));
}

switch ($_REQUEST['doing']) {
    case 'change':
        Capsule::table('mod_PortForwardGo_Users')->where('sid', $_REQUEST['id'])->update(['api' => PortForwardGo_CreateToken(rand(7, 10))]);
        break;

    case 'off':
        Capsule::table('mod_PortForwardGo_Users')->where('sid', $_REQUEST['id'])->update(['api' => 'disabled']);
        break;
}
exit(json_encode(["result" => "success", "msg" => "操作已完成"]));
