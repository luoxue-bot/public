<?php
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use Illuminate\Database\Capsule\Manager as Capsule;

if (!isset($_REQUEST["id"]) || !isset($_REQUEST["ruleid"])) {
    exit("无效请求");
}


$sql = Capsule::table('mod_PortForwardGo_Rules')->where('id', $_REQUEST['ruleid'])->where('status', '!=', 'Deleted');
if (!$sql->exists()) {
    exit(json_encode(['result' => 'error', 'error' => '规则不存在']));
}
$data = $sql->first();
switch ($data->protocol) {
    case  'wsc':
        $arr = [
            "Mode" => "Server",
            "Rules" => [
                (string)$data->id => [
                    "TLS" => false,
                    "Port" => $data->remoteport,
                    "Address" => "TCP服务器IP:端口",
                    "ProxyProtocolVersion" => (int)$data->proxyprotocolversion,
                ],
            ],
        ];
        break;
    case "wssc":
        $arr = [
            "Mode" => "Server",
            "Rules" => [
                (string)$data->id => [
                    "TLS" => true,
                    "Port" => $data->remoteport,
                    "Address" => "TCP服务器IP:端口",
                    "ProxyProtocolVersion" => (int)$data->proxyprotocolversion,
                ],
            ],
        ];
        break;
    default:
        exit("Error");
}
$file=json_encode($arr);
header("Content-type: application/octet-stream");
header("Accept-Ranges: bytes");
header("Accept-Length: " . strlen($file));
header("Content-Disposition: attachment; filename=config.json");
exit($file);
