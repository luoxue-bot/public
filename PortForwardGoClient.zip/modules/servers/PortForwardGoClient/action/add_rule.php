<?php
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use Illuminate\Database\Capsule\Manager as Capsule;

require_once(__DIR__ . '/../../../addons/PortForwardGo/func.php');

if (!isset($_REQUEST["remoteip"]) || !isset($_REQUEST["remoteport"]) || !isset($_REQUEST["port"]) || !isset($_REQUEST['protocol']) || !isset($_REQUEST['node']) || !isset($_REQUEST['rc'])) {
    exit(json_encode(["result" => "error", "error" => "无效请求"]));
}

$_REQUEST['port'] = strtolower($_REQUEST['port']);

$sql = Capsule::table('mod_PortForwardGo_Users')->where('sid', $_REQUEST['id']);
if (!$sql->exists()) {
    exit(json_encode(["result" => "error", "error" => "服务不存在"]));
}
$sql = $sql->first();

if (!PortForwardGo_CheckUser($_REQUEST['id'])) {
    exit(json_encode(["result" => "error", "error" => "服务状态异常"]));
}

$is_domain = preg_match("/^(?!:\/\/)(?!.{256,})(([a-z0-9][a-z0-9_-]*?)|([a-z0-9][a-z0-9_-]*?\.)+?[a-z]{2,15}?)$/i", $_REQUEST['remoteip']);
if (!filter_var(trim($_REQUEST['remoteip']), FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_IPV6)) {
    if (!$is_domain) {
        exit(json_encode(["result" => "error", "error" => "目标地址不合法"]));
    }
}

if ($_REQUEST["remoteport"] < 1 || $_REQUEST["remoteport"] > 65535) {
    exit(json_encode(["result" => "error", "error" => "目标端口不可用"]));
}

if ($sql->max_rules <= Capsule::table('mod_PortForwardGo_Rules')->where('sid', $sql->sid)->where('status', '!=', 'Deleted')->count()) {
    exit(json_encode(["result" => "error", "error" => "已达到限额"]));
}

if (!PortForwardGo_VeifyNode($sql->pid, $_REQUEST['node'])) {
    exit(json_encode(["result" => "error", "error" => "内部错误"]));
}

if ((bool)$_REQUEST['rc'] && !PortForwardGo_VeifyRemotePort($_REQUEST['node'], $_REQUEST["remoteport"])) {
    exit(json_encode(["result" => "error", "error" => "目标端口不可用"]));
}

if (!PortForwardGo_GetAllowProtocol($sql->pid, $_REQUEST['node'])[$_REQUEST['protocol']]) {
    exit(json_encode(["result" => "error", "error" => "不支持此协议"]));
}

if (in_array($_REQUEST['protocol'], ['http', 'https'])) {
    $is_domain = preg_match("/^(?!:\/\/)(?!.{256,})(([a-z0-9][a-z0-9_-]*?)|([a-z0-9][a-z0-9_-]*?\.)+?[a-z]{2,15}?)$/i", $_REQUEST['port']);
    if (!$is_domain || preg_match("/^-?\d+$/", $_REQUEST['port'])) {
        exit(json_encode(["result" => "error", "error" => "域名不可用"]));
    }

    if (!PortForwardGo_VeifyDomainICP($_REQUEST['node'], $_REQUEST['port'])) {
        exit(json_encode(["result" => "error", "error" => "请先备案"]));
    }
} else {
    if (!preg_match("/^-?\d+$/", $_REQUEST['port']) || $_REQUEST["port"] < 1 || $_REQUEST["port"] > 65535) {
        exit(json_encode(["result" => "error", "error" => "监听端口不可用"]));
    }
    if (!PortForwardGo_VeifyPort($_REQUEST['node'], $_REQUEST["port"])) {
        exit(json_encode(["result" => "error", "error" => "监听端口不可用"]));
    }
}

if (!PortForwardGo_CheckPort($_REQUEST['node'], $_REQUEST['protocol'], $_REQUEST['port'])) {
    exit(json_encode(["result" => "error", "error" => "监听端口(域名)已被占用"]));
}

$data = Capsule::table("mod_PortForwardGo_Node")->where('id', $_REQUEST['node'])->first();
$msg = '连接地址：' . $data->addr . '<br>连接端口(绑定域名)：' . $_REQUEST['port'] . '<br>目标地址：' . $_REQUEST['remoteip'] . '<br>目标端口：' . $_REQUEST['remoteport'] . '<br>协议：' . PortForwardGo_AllProtocol()[$_REQUEST['protocol']] . "<br>代理协议：" . PortForwardGo_AllProxyProtocolVersion()[$_REQUEST['proxyprotocolversion']] . '<br>备注: ' . $_REQUEST['msg'];

$ruleid = Capsule::table("mod_PortForwardGo_Rules")->insertGetId([
    "sid" => $sql->sid,
    "port" => $_REQUEST["port"],
    "remoteport" => $_REQUEST["remoteport"],
    "remoteip" => $_REQUEST["remoteip"],
    "protocol" => $_REQUEST["protocol"],
    "proxyprotocolversion" => $_REQUEST['proxyprotocolversion'] ?? "",
    "rc" => (bool)$_REQUEST['rc'],
    "msg" => $_REQUEST['msg'] ?? "",
    "node" => $_REQUEST['node'],
    "status" => "Created",
]);

if ((bool)$_REQUEST['rc']) {
    Capsule::table("mod_PortForwardGo_RClient_Changes")->insert(['sid' => $sql->sid, 'node' => $_REQUEST['node'], 'rule_id' => $ruleid, 'status' => 'Created']);
}

if (PortForwardGo_APICall($ruleid)) {
    Capsule::table("mod_PortForwardGo_Rules")->where("id", $ruleid)->update(['status' => 'Active']);
}

exit(json_encode(["result" => "success", 'msg' => $msg]));
