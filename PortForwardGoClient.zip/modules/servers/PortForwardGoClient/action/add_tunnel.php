<?php
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use Illuminate\Database\Capsule\Manager as Capsule;

require_once(__DIR__ . '/../../../addons/PortForwardGo/func.php');

if (!isset($_REQUEST["remoteip"]) || !isset($_REQUEST["remoteport"]) || !isset($_REQUEST["port"]) || !in_array($_REQUEST['protocol'], ['ws', 'wss', 'stcp', 'sudp']) || !isset($_REQUEST['in_node']) || !isset($_REQUEST['out_node'])) {
    exit(json_encode(["result" => "error", "error" => "无效请求"]));
}

switch ($_REQUEST['protocol']) {
    case 'ws':
        $in_protocol = 'wsc';
        $out_protocol = 'ws';
        break;
    case 'wss':
        $in_protocol = 'wssc';
        $out_protocol = 'wss';
        break;
    case 'stcp':
        $in_protocol = 'stcpc';
        $out_protocol = 'stcp';
        break;
    case 'sudp':
        $in_protocol = 'sudpc';
        $out_protocol = 'sudp';
        break;
}

$_REQUEST['port'] = strtolower($_REQUEST['port']);

$sql = Capsule::table('mod_PortForwardGo_Users')->where('sid', $_REQUEST['id']);
if (!$sql->exists()) {
    exit(json_encode(["result" => "error", "error" => "服务不存在"]));
}
$sql = $sql->first();

if (!PortForwardGo_CheckUser($_REQUEST['id'])) {
    exit(json_encode(["result" => "error", "error" => "服务状态异常"]));
}

$is_domain = preg_match("/^(?!:\/\/)(?!.{256,})(([a-z0-9][a-z0-9_-]*?)|([a-z0-9][a-z0-9_-]*?\.)+?[a-z]{2,15}?)$/i", $_REQUEST['remoteip']);
if (!filter_var(trim($_REQUEST['remoteip']), FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_IPV6)) {
    if (!$is_domain) {
        exit(json_encode(["result" => "error", "error" => "目标地址不合法"]));
    }
}

if ($_REQUEST["port"] < 1 || $_REQUEST["port"] > 65535) {
    exit(json_encode(["result" => "error", "error" => "监听端口不可用"]));
}

if ($_REQUEST["remoteport"] < 1 || $_REQUEST["remoteport"] > 65535) {
    exit(json_encode(["result" => "error", "error" => "目标端口不可用"]));
}

if ($sql->max_rules <= (Capsule::table('mod_PortForwardGo_Rules')->where('sid', $sql->sid)->where('status', '!=', 'Deleted')->count() + 1)) {
    exit(json_encode(["result" => "error", "error" => "已达到限额"]));
}

if (!PortForwardGo_VeifyNode($sql->pid, $_REQUEST['in_node']) || !PortForwardGo_VeifyNode($sql->pid, $_REQUEST['out_node'])) {
    exit(json_encode(["result" => "error", "error" => "内部错误"]));
}

if (!PortForwardGo_GetAllowProtocol($sql->pid, $_REQUEST['in_node'])[$in_protocol] || !PortForwardGo_GetAllowProtocol($sql->pid, $_REQUEST['out_node'])[$out_protocol]) {
    exit(json_encode(["result" => "error", "error" => "不支持此协议"]));
}

if (!PortForwardGo_VeifyPort($_REQUEST['in_node'], $_REQUEST["port"])) {
    exit(json_encode(["result" => "error", "error" => "监听端口不可用"]));
}

$tunnel_port = rand(10000, 65535);
while (PortForwardGo_VeifyRemotePort($_REQUEST['in_node'], $tunnel_port) || PortForwardGo_VeifyPort($_REQUEST['out_node'], $tunnel_port) || PortForwardGo_CheckPort($_REQUEST['out_node'], $out_protocol, $tunnel_port)) {
    $tunnel_port = rand(10000, 65535);
}

if (!PortForwardGo_VeifyRemotePort($_REQUEST['out_node'], $_REQUEST["remoteport"])) {
    exit(json_encode(["result" => "error", "error" => "目标端口不可用"]));
}

if (!PortForwardGo_CheckPort($_REQUEST['in_node'], $in_protocol, $_REQUEST['port'])) {
    exit(json_encode(["result" => "error", "error" => "监听端口已被占用"]));
}

$data = Capsule::table("mod_PortForwardGo_Node")->where('id', $_REQUEST['in_node'])->first();
$msg = '连接地址：' . $data->addr . '<br>连接端口：' . $_REQUEST['port'] . '<br>目标地址：' . $_REQUEST['remoteip'] . '<br>目标端口：' . $_REQUEST['remoteport'] . '<br>隧道协议：' . PortForwardGo_AllTunnelProtocol()[$_REQUEST['protocol']] . "<br>代理协议：" . PortForwardGo_AllProxyProtocolVersion()[$_REQUEST['proxyprotocolversion']];

$in_ruleid = Capsule::table("mod_PortForwardGo_Rules")->insertGetId([
    "sid" => $sql->sid,
    "port" => $_REQUEST["port"],
    "remoteport" => $tunnel_port,
    "remoteip" => Capsule::table("mod_PortForwardGo_Node")->where('id', $_REQUEST['out_node'])->first()->addr,
    "protocol" => $in_protocol,
    "proxyprotocolversion" => 0,
    "msg" => "",
    "node" => $_REQUEST['in_node'],
    "status" => "Created",
]);

if (PortForwardGo_APICall($in_ruleid)) {
    Capsule::table("mod_PortForwardGo_Rules")->where("id", $in_ruleid)->update(['status' => 'Active']);
}

$out_ruleid = Capsule::table("mod_PortForwardGo_Rules")->insertGetId([
    "sid" => $sql->sid,
    "port" => $tunnel_port,
    "remoteport" => $_REQUEST["remoteport"],
    "remoteip" => $_REQUEST["remoteip"],
    "protocol" => $out_protocol,
    "proxyprotocolversion" => 0,
    "msg" => "",
    "node" => $_REQUEST['out_node'],
    "status" => "Created",
]);

if (PortForwardGo_APICall($out_ruleid)) {
    Capsule::table("mod_PortForwardGo_Rules")->where("id", $out_ruleid)->update(['status' => 'Active']);
}

exit(json_encode(["result" => "success", 'msg' => $msg]));
