<?php
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use Illuminate\Database\Capsule\Manager as Capsule;

require_once(__DIR__ . '/../../../addons/PortForwardGo/func.php');
if (!isset($_REQUEST["node"])) {
    exit(json_encode(["result" => "error", "error" => "无效请求"]));
}
$sql = Capsule::table('mod_PortForwardGo_Node')->where('id', $_REQUEST['node']);
if (!$sql->exists()) {
    exit(json_encode(["result" => "error", "error" => '节点不存在!']));
}
$data = $sql->first();
$protocols = json_decode($data->protocol, true);

$title = '节点(' . $data->name . ')的信息';
$html = '连接地址：' . $data->addr . '<br>' . '速率控制：' . $data->speed_times . '倍<br>' . '流量消耗：' . $data->traffic_times . '倍<br>同步周期：' . $data->cron . '秒<br>' . '上次同步：' . $data->updated . '<br><br>';

if (!empty($data->description)) {
    $html .= '描述:' . $data->description . '<br><br>';
}

foreach ($protocols as $protocol => $status) {
    if ($status) {
        $html .= PortForwardGo_AllProtocol()[$protocol] . '协议：<a style="color: #0C0">开放</a><br>';
    } else {
        $html .= PortForwardGo_AllProtocol()[$protocol] . '协议：<a style="color: #F00">关闭</a><br>';
    }
}

if ($protocols['http']) {
    $html .= 'HTTP端口：' . $data->http_port;
    if ($data->http_port != $data->http_port_2) {
        $html .= ' ' . $data->http_port_2;
    }
    $html .= '<br>';
}

if ($protocols['https']) {
    $html .= 'HTTPS端口：' . $data->https_port;
    if ($data->https_port != $data->https_port_2) {
        $html .= ' ' . $data->https_port_2;
    }
    $html .= '<br>';
}

if (($protocols['http'] || $protocols['https']) && (bool)$data->icp) {
    $html .= '<strong>此节点使用HTTP(S)协议域名需ICP备案</strong><br>';
}

if (!empty($data->retain_remoteport)) {
    $html .= '<br>保留的目标端口列表:';

    $retain_remoteports = explode(PHP_EOL, $data->retain_remoteport);

    foreach ($retain_remoteports as $retain_remoteport) {
        $html .= '<br>' . $retain_remoteport;
    }
    $html .= '<br>';
}

if (($protocols['tcp'] || $protocols['udp']) && !empty($data->retain_port)) {
    $html .= '<br>保留的监听端口列表:';

    $retain_ports = explode(PHP_EOL, $data->retain_port);

    array_push($retain_ports, $data->apiport);
    array_push($retain_ports, $data->http_port);
    array_push($retain_ports, $data->https_port);
    if ($data->rc_tcp_port != "0") {
        array_push($retain_ports, $data->rc_tcp_port);
        if ($data->rc_kcp_port != "0" && $data->rc_tcp_port != $data->rc_kcp_port) {
            array_push($retain_ports, $data->rc_kcp_port);
        }
    }
    if ($data->http_port != $data->http_port_2) {
        array_push($retain_ports, $data->http_port_2);
    }
    if ($data->https_port != $data->https_port_2) {
        array_push($retain_ports, $data->https_port_2);
    }

    foreach ($retain_ports as $retain_port) {
        $html .= '<br>' . $retain_port;
    }
}

exit(json_encode(['result' => 'success', 'title' => $title, 'html' => $html]));
