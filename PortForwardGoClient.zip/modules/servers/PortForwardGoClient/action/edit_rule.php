<?php
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use Illuminate\Database\Capsule\Manager as Capsule;

if (!isset($_REQUEST["id"]) || !isset($_REQUEST["remoteip"]) || !isset($_REQUEST["remoteport"]) || !isset($_REQUEST["ruleid"]) || !isset($_REQUEST['proxyprotocolversion']) || !isset($_REQUEST['rc'])) {
    exit(json_encode(["result" => "error", "error" => "无效请求"]));
}

$is_domain = preg_match("/^(?!:\/\/)(?!.{256,})(([a-z0-9][a-z0-9_-]*?)|([a-z0-9][a-z0-9_-]*?\.)+?[a-z]{2,6}?)$/i", $_REQUEST['remoteip']);
if (!filter_var(trim($_REQUEST['remoteip']), FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_IPV6)) {
    if (!$is_domain) {
        exit(json_encode(["result" => "error", "error" => "目标地址不合法"]));
    }
}

if ($_REQUEST["remoteport"] <= 0 || $_REQUEST["remoteport"] > 65535) {
    exit(json_encode(["result" => "error", "error" => "目标端口不可用"]));
}

$sql = Capsule::table('mod_PortForwardGo_Rules')->where('id', $_REQUEST['ruleid'])->where('status', '!=', 'Deleted');
if (!$sql->exists()) {
    exit(json_encode(['result' => 'error', 'error' => '规则不存在']));
}
$data = $sql->first();
if ($data->status == "Suspend") {
    exit(json_encode(["result" => "error", "error" => "权限不足"]));
}

if ((bool)$_REQUEST['rc'] && !PortForwardGo_VeifyRemotePort($data->node, $_REQUEST["remoteport"])) {
    exit(json_encode(["result" => "error", "error" => "目标端口不可用"]));
}

if (!(bool)$data->rc && $_REQUEST['rc'] == "1") {
    $rc_sql = Capsule::table("mod_PortForwardGo_RClient_Changes")->where("rule_id", $data->id)->where('status', 'Deleted');
    if ($rc_sql->exists()) {
        $rc_sql->delete();
    } else {
        Capsule::table("mod_PortForwardGo_RClient_Changes")->insert(['sid' => $data->sid, 'node' => $data->node, 'rule_id' => $data->id, 'status' => 'Created']);
    }
}

if ((bool)$data->rc && $_REQUEST['rc'] == "0") {
    $rc_sql = Capsule::table("mod_PortForwardGo_RClient_Changes")->where("rule_id", $data->id)->where('status', 'Created');
    if ($rc_sql->exists()) {
        $rc_sql->delete();
    } else {
        Capsule::table("mod_PortForwardGo_RClient_Changes")->insert(['sid' => $data->sid, 'node' => $data->node, 'rule_id' => $data->id, 'status' => 'Deleted']);
    }
}

$sql->update([
    'remoteip' => $_REQUEST['remoteip'],
    'remoteport' => $_REQUEST['remoteport'],
    "proxyprotocolversion" => $_REQUEST['proxyprotocolversion'],
    "rc" => (bool)$_REQUEST['rc'],
    "msg" => $_REQUEST['msg'],
]);

$node_data = Capsule::table("mod_PortForwardGo_Node")->where('id', $sql->first()->node)->first();
$msg = '连接地址：' . $node_data->addr . '<br>连接端口(绑定域名)：' . $data->port . '<br>目标地址：' . $_REQUEST['remoteip'] . '<br>目标端口：' . $_REQUEST['remoteport'] . '<br>协议：' . PortForwardGo_AllProtocol()[$data->protocol] . "<br>代理协议：" . PortForwardGo_AllProxyProtocolVersion()[$_REQUEST['proxyprotocolversion']] . '<br>备注: ' . $_REQUEST['msg'] . "<br>";


if (PortForwardGo_APICall($_REQUEST['ruleid'])) {
    $msg .= "状态: 已生效";
} else {
    $msg .= "状态: 待同步";
}
exit(json_encode(['result' => 'success', 'msg' => $msg]));
