<?php
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use Illuminate\Database\Capsule\Manager as Capsule;

if (!isset($_REQUEST["id"]) || !isset($_REQUEST["ruleid"])) {
    exit("无效请求");
}


$sql = Capsule::table('mod_PortForwardGo_Rules')->where('id', $_REQUEST['ruleid'])->where('status', '!=', 'Deleted');
if (!$sql->exists()) {
    exit(json_encode(['result' => 'error', 'error' => '规则不存在']));
}
$data = $sql->first();
$addr = Capsule::table("mod_PortForwardGo_Node")->where('id', $data->node)->first()->addr;
if (filter_var($addr, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
    $addr = '[' + $addr + ']';
}

$SecureKey = Capsule::table("mod_PortForwardGo_Setting")->where('name', 'key')->first()->value;
switch ($data->protocol) {
    case "ws":
        $arr = [
            "Mode" => "Client",
            "Rules" => [
                (string)$data->id => [
                    "TLS" => false,
                    "Port" => $data->port,
                    "Address" => $addr . ":" . $data->port,
                    "ProxyProtocolVersion" => 0,
                ],
            ],
        ];
        break;
    case "wss":
        $arr = [
            "Mode" => "Client",
            "Rules" => [
                (string)$data->id => [
                    "TLS" => true,
                    "Port" => $data->port,
                    "Address" => $addr . ":" . $data->port,
                    "ProxyProtocolVersion" => 0,
                ],
            ],
        ];
        break;
    case "stcp":
        $arr = [
            (string)$data->id => [
                "SecureKey" => $SecureKey,
                "Port" => $data->port,
                "Address" => $addr . ":" . $data->port,
                "Protocol" => "tcp",
            ],
        ];
        break;
    case "sudp":
        $arr = [
            (string)$data->id => [
                "SecureKey" => $SecureKey,
                "Port" => $data->port,
                "Address" => $addr . ":" . $data->port,
                "Protocol" => "udp",
            ],
        ];
        break;
    default:
        exit("Error");
}

$file = json_encode($arr);
header("Content-type: application/octet-stream");
header("Accept-Ranges: bytes");
header("Accept-Length: " . strlen($file));
header("Content-Disposition: attachment; filename=config.json");
exit($file);
