<?php
set_time_limit(0);
require_once __DIR__ . "/../../../init.php";
require_once(__DIR__ . '/../../addons/PortForwardGo/func.php');

use Illuminate\Database\Capsule\Manager as Capsule;

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    exit('Unsupport Method');
}

$config = PortForwardGo_GetConfigModule();
$postdata = json_decode(file_get_contents("php://input"), true);

if (!is_array($postdata) || !isset($_REQUEST['token'])) {
    header("HTTP/1.1 503 Service Unavailable");
    exit('Wrong Request.');
}

$params = base64_decode($_REQUEST['token'], true);
if ($params == false) {
    header("HTTP/1.1 503 Service Unavailable");
    exit('Wrong Token.');
}

$params = explode("|", $params);
if (count($params) > 2) {
    header("HTTP/1.1 503 Service Unavailable");
    exit('Wrong Token.');
}
$id = $params[0];
$sid = $params[1];

if (!Capsule::table("mod_PortForwardGo_Users")->where('id', $id)->where('sid', $sid)->exists()) {
    header("HTTP/1.1 503 Service Unavailable");
    exit('Wrong Token.');
}

if ($postdata['Action'] == 'GetConfig') {
    $sql = Capsule::table('mod_PortForwardGo_Node')->where('id', $postdata['NodeID']);

    if (!$sql->exists()) {
        header("HTTP/1.1 503 Service Unavailable");
        exit('Wrong NodeID');
    }
    $data = $sql->first();

    $conf = array(
        'Token' => $config['key'],
        'Addr' => $data->addr,
        'TCP_Remote_Port' => (string)$data->rc_tcp_port,
        'KCP_Remote_Port' => (string)$data->rc_kcp_port,
    );
    exit(json_encode($conf));
}

if ($postdata['Action'] == 'GetRules') {
    if (!Capsule::table('mod_PortForwardGo_Node')->where('id', $postdata['NodeID'])->exists()) {
        header("HTTP/1.1 503 Service Unavailable");
        exit('Wrong NodeID');
    }

    Capsule::table('mod_PortForwardGo_RClient_Changes')->where('node', $postdata['NodeID'])->where('sid', $sid)->delete();

    if (!Capsule::table("mod_PortForwardGo_Rules")->where('sid', $sid)->where('node', $postdata['NodeID'])->where('rc', 1)->exists() && !Capsule::table("mod_PortForwardGo_RClient_Changes")->where('sid', $sid)->where('node', $postdata['NodeID'])->exists()) {
        header('HTTP/1.1 204 No Content');
        exit;
    }

    $conf = [];
    $rules = Capsule::table("mod_PortForwardGo_Rules")->where('sid', $sid)->where('node', $postdata['NodeID'])->where('rc', 1)->get();
    foreach ($rules as $rule) {
        if ($rule->status == "Created") {
            Capsule::table('mod_PortForwardGo_RClient_Changes')->insert(['sid' => $sid, 'node' => $postdata['NodeID'], 'rule_id' => $rule->id, 'status' => 'Created']);
            continue;
        }
        $conf[(string)$rule->id]['Status'] = $rule->status;
        $conf[(string)$rule->id]['Protocol'] = $rule->protocol;
        $conf[(string)$rule->id]['Port'] = $rule->port;
        $conf[(string)$rule->id]['RemoteHost'] = $rule->remoteip;
        $conf[(string)$rule->id]['RemotePort'] = (int)$rule->remoteport;
    }

    exit(json_encode($conf));
}

if ($postdata['Action'] == 'UpdateRules') {
    if (!Capsule::table('mod_PortForwardGo_Node')->where('id', $postdata['NodeID'])->exists()) {
        header("HTTP/1.1 503 Service Unavailable");
        exit('Wrong NodeID');
    }

    if (!Capsule::table("mod_PortForwardGo_Rules")->where('sid', $sid)->where('node', $postdata['NodeID'])->where('rc', 1)->exists() && !Capsule::table("mod_PortForwardGo_RClient_Changes")->where('sid', $sid)->where('node', $postdata['NodeID'])->exists()) {
        header('HTTP/1.1 204 No Content');
        exit;
    }

    $conf = [];
    $rules = Capsule::table("mod_PortForwardGo_Rules")->where('sid', $sid)->where('node', $postdata['NodeID'])->where('rc', 1)->get();
    foreach ($rules as $rule) {
        if ($rule->status == "Created") {
            Capsule::table('mod_PortForwardGo_RClient_Changes')->insert(['sid' => $sid, 'node' => $postdata['NodeID'], 'rule_id' => $rule->id, 'status' => 'Created']);
            continue;
        }
        $conf[(string)$rule->id]['Status'] = $rule->status;
        $conf[(string)$rule->id]['Protocol'] = $rule->protocol;
        $conf[(string)$rule->id]['Port'] = $rule->port;
        $conf[(string)$rule->id]['RemoteHost'] = $rule->remoteip;
        $conf[(string)$rule->id]['RemotePort'] = (int)$rule->remoteport;
    }

    $deletes = [];
    $changes = Capsule::table("mod_PortForwardGo_RClient_Changes")->where('sid', $sid)->where('node', $postdata['NodeID'])->get();

    if (count($changes) != 0) {
        foreach ($changes as $change) {
            switch ($change->status) {
                case "Created":
                    if (isset($conf[(string)$change->rule_id])) {
                        $deletes[] = $change->id;
                        $conf[(string)$change->rule_id]['Status'] = $change->status;
                    }
                    break;
                case "Deleted":
                    $deletes[] = $change->id;
                    $conf[(string)$change->rule_id]['Status'] = "Deleted";
                    $conf[(string)$change->rule_id]['Protocol'] = "";
                    $conf[(string)$change->rule_id]['Port'] = "";
                    $conf[(string)$change->rule_id]['RemoteHost'] = "";
                    $conf[(string)$change->rule_id]['RemotePort'] = 0;
                    break;
            }
        }

        if (count($deletes) != 0) {
            Capsule::table('mod_PortForwardGo_RClient_Changes')->whereIn('id', $deletes)->delete();
        }
    }

    exit(json_encode($conf));
}
