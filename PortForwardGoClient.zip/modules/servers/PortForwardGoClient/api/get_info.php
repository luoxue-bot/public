<?php
require_once __DIR__ . '/../../../addons/PortForwardGo/func.php';

use Illuminate\Database\Capsule\Manager as Capsule;

if (!defined("WHMCS_API")) {
    die("This file cannot be accessed directly");
}

$plan = Capsule::table("mod_PortForwardGo_Plans")->where('id', $user->pid)->first();
$data['rules']['limit'] = $user->max_rules;
$data['rules']['used'] = Capsule::table('mod_PortForwardGo_Rules')->where('sid', $user->sid)->count();
$data['speed'] = $user->speed;
$data['conn'] = $user->max_conn;
$data['traffic']['limit'] = $user->traffic / 1073741824;
$data['traffic']['used'] = $user->traffic_used / 1073741824;
$data['protocol'] = json_decode($plan->protocol, true);

$available_nodes = explode("|", $plan->node);
$sql = Capsule::table("mod_PortForwardGo_Node")->get();
foreach ($sql as $node) {
    if (in_array($node->id, $available_nodes)) {
        $nodes[] = $node->id;
    }
}

$data['nodes'] = $nodes;

exit(json_encode(['success' => true, 'data' => $data]));
