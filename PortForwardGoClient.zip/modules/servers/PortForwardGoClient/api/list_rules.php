<?php
require_once __DIR__ . '/../../../addons/PortForwardGo/func.php';

use Illuminate\Database\Capsule\Manager as Capsule;

if (!defined("WHMCS_API")) {
    die("This file cannot be accessed directly");
}

$sql = Capsule::table("mod_PortForwardGo_Rules")->where('sid', $user->sid)->get();
foreach ($sql as $rule) {
    $rules[$rule->id] = $rule;
}

exit(json_encode(['success' => true, 'data' => $rules]));
