<?php
require_once __DIR__ . '/../../../addons/PortForwardGo/func.php';

use Illuminate\Database\Capsule\Manager as Capsule;

if (!defined("WHMCS_API")) {
    die("This file cannot be accessed directly");
}

if (!isset($params["rule_id"])) {
    exit(json_encode(["success" => false, "msg" => "Missing parameter"]));
}

$sql = Capsule::table('mod_PortForwardGo_Rules')->where('sid', $user->sid)->where('id', $params['rule_id'])->where('status', '!=', 'Deleted');
if (!$sql->exists()) {
    exit(json_encode(["success" => false, "msg" => 'Rule not found']));
}

$info = $sql->first();
if ($info->status == "Suspend") {
    exit(json_encode(["success" => false, "msg" => 'Permission denied']));
}

foreach ($info as $name => $value) {
    $data[$name] = $value;
}

if (isset($params['remoteip'])) {
    $is_domain = preg_match("/^(?!:\/\/)(?!.{256,})(([a-z0-9][a-z0-9_-]*?)|([a-z0-9][a-z0-9_-]*?\.)+?[a-z]{2,6}?)$/i", $params['remoteip']);
    if (!filter_var(trim($params['remoteip']), FILTER_VALIDATE_IP, FILTER_FLAG_NO_RES_RANGE | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_IPV4)) {
        if (!$is_domain) {
            exit(json_encode(["success" => false, "msg" => "Invalid remoteip"]));
        }
    }
    $data['remoteip'] = $params['remoteip'];
}


if (isset($params['remoteport'])) {
    if ($params["remoteport"] <= 0 || $params["remoteport"] > 65535) {
        exit(json_encode(["success" => false, "msg" => "Invalid remoteport"]));
    }

    $data['remoteport'] = $params['remoteport'];
}

if (isset($params['proxyprotocolversion'])) {
    if (!in_array($params['proxyprotocolversion'], [0, 1, 2])) {
        exit(json_encode(["success" => false, "msg" => "Invalid proxyprotocolversion"]));
    }
    $data['proxyprotocolversion'] = $params['proxyprotocolversion'];
}

if (isset($params['msg'])) {
    $data['msg'] = $params['msg'];
}

if (isset($params['rc'])) {
    $data['rc'] = (bool)$params['rc'];
}

if (isset($params['status'])) {
    if (!in_array($params['status'], ['Active', 'Disabled'])) {
        exit(json_encode(["success" => false, "msg" => "Invalid status"]));
    }
    $data['status'] = $params['status'];
}

$sql->update($data);
if (isset($params['rc'])) {
    if (!(bool)$info->rc && (bool)$params['rc']) {
        $sql = Capsule::table("mod_PortForwardGo_RClient_Changes")->where("rule_id", $info->id)->where('status', 'Deleted');
        if ($sql->exists()) {
            $sql->delete();
        } else {
            Capsule::table("mod_PortForwardGo_RClient_Changes")->insert(['sid' => $info->sid, 'node' => $info->node, 'rule_id' => $info->id, 'status' => 'Created']);
        }
    }

    if ((bool)$info->rc && !(bool)$params['rc']) {
        $sql = Capsule::table("mod_PortForwardGo_RClient_Changes")->where("rule_id", $info->id)->where('status', 'Created');
        if ($sql->exists()) {
            $sql->delete();
        } else {
            Capsule::table("mod_PortForwardGo_RClient_Changes")->insert(['sid' => $info->sid, 'node' => $info->node, 'rule_id' => $info->id, 'status' => 'Deleted']);
        }
    }
}

if (PortForwardGo_APICall($params['ruleid'])) {
    $sync = true;
} else {
    $sync = false;
}

exit(json_encode(["success" => true, "data" => ['sync' => $sync]]));
