<?php
require_once __DIR__ . '/../../../addons/PortForwardGo/func.php';

use Illuminate\Database\Capsule\Manager as Capsule;

if (!defined("WHMCS_API")) {
    die("This file cannot be accessed directly");
}

if (!isset($params["rule_id"])) {
    exit(json_encode(["success" => false, "msg" => "Missing parameter"]));
}

$sql = Capsule::table('mod_PortForwardGo_Rules')->where('sid', $user->sid)->where('id', $params['rule_id'])->where('status', '!=', 'Deleted');
if (!$sql->exists()) {
    exit(json_encode(["success" => false, "msg" => 'Rule not found']));
}

$data = $sql->first();
if ($data->status == 'Created') {
    if ((bool)$data->rc) {
        Capsule::table("mod_PortForwardGo_RClient_Changes")->where("rule_id", $data->id)->delete();
    }
    $sql->delete();
} else if ($data->status == 'Suspend') {
    exit(json_encode(["success" => false, "error" => "Permission denied"]));
} else {
    $sql->update(['status' => 'Deleted']);
    if ((bool)$data->rc) {
        $sql = Capsule::table("mod_PortForwardGo_RClient_Changes")->where('node', $data->node)->where('rule_id', $data->id);
        if ($sql->exists()) {
            $sql->delete();
        } else {
            Capsule::table("mod_PortForwardGo_RClient_Changes")->insert(['sid' => $data->sid, 'node' => $data->node, 'rule_id' => $data->id, 'status' => 'Deleted']);
        }
    }
    if (PortForwardGo_APICall($params['ruleid'])) {
        Capsule::table('mod_PortForwardGo_Rules')->where('sid', $user->sid)->where('id', $params['ruleid'])->delete();
    }
}

exit(json_encode(['success' => true]));
