<?php
require_once __DIR__ . '/../../../addons/PortForwardGo/func.php';

use Illuminate\Database\Capsule\Manager as Capsule;

if (!defined("WHMCS_API")) {
    die("This file cannot be accessed directly");
}

if (!isset($_REQUEST['node_id'])) {
    exit(json_encode(['success' => false, 'msg' => 'Missing parameter']));
}

$available_nodes = explode("|", Capsule::table("mod_PortForwardGo_Plans")->where('id', $user->pid)->first()->node);

if (!in_array($_REQUEST['node_id'], $available_nodes)) {
    exit(json_encode(['success' => false, 'msg' => 'Node not found']));
}

if (!Capsule::table("mod_PortForwardGo_Node")->where('id', $_REQUEST['node_id'])->exists()) {
    exit(json_encode(['success' => false, 'msg' => 'Node not found']));
}

$data = Capsule::table("mod_PortForwardGo_Node")->where('id', $_REQUEST['node_id'])->first();
$node = $data;
$node->protocol = json_decode($data->protocol, true);
$node->retain_remoteport = explode("\r\n", $data->retain_remoteport);
$node->retain_port = explode("\r\n", $data->retain_port);
$node->icp = (bool)$node->icp;
unset($node->rc_tcp_port);
unset($node->rc_kcp_port);
unset($node->api);
unset($node->apiport);

exit(json_encode(['success' => true, 'data' => $node]));
