<?php
require_once __DIR__ . '/../../../addons/PortForwardGo/func.php';

use Illuminate\Database\Capsule\Manager as Capsule;

if (!defined("WHMCS_API")) {
    die("This file cannot be accessed directly");
}

$available_nodes = explode("|", Capsule::table("mod_PortForwardGo_Plans")->where('id', $user->pid)->first()->node);
$sql = Capsule::table("mod_PortForwardGo_Node")->get();
foreach ($sql as $node) {
    if (in_array($node->id, $available_nodes)) {
        unset($node->api);
        unset($node->apiport);
        unset($node->rc_tcp_port);
        unset($node->rc_kcp_port);
        $node->protocol = json_decode($node->protocol, true);
        $node->retain_remoteport = explode("\r\n", $node->retain_remoteport);
        $node->retain_port = explode("\r\n", $node->retain_port);
        $node->icp = (bool)$node->icp;
        $nodes[] = $node;
    }
}

exit(json_encode(['success' => true, 'data' => $nodes]));
