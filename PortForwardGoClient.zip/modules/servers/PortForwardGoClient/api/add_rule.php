<?php
require_once __DIR__ . '/../../../addons/PortForwardGo/func.php';

use Illuminate\Database\Capsule\Manager as Capsule;

if (!defined("WHMCS_API")) {
    die("This file cannot be accessed directly");
}


if (!isset($params["remoteip"]) || !isset($params["remoteport"]) || !isset($params["port"]) || !isset($params['protocol']) || !isset($params['node'])) {
    exit(json_encode(["success" => false, "msg" => "Missing parameter"]));
}

$params['port'] = strtolower($params['port']);
$params['rc'] = isset($params['rc']) ? (bool)$params['rc'] : false;
$params['proxyprotocolversion'] = isset($params['proxyprotocolversion']) ? $params['proxyprotocolversion'] : 0;

if (!PortForwardGo_CheckUser($params['id'])) {
    exit(json_encode(["success" => false, "msg" => "Your service is abnormal"]));
}

$is_domain = preg_match("/^(?!:\/\/)(?!.{256,})(([a-z0-9][a-z0-9_-]*?)|([a-z0-9][a-z0-9_-]*?\.)+?[a-z]{2,15}?)$/i", $params['remoteip']);
if (!filter_var(trim($params['remoteip']), FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_IPV6)) {
    if (!$is_domain) {
        exit(json_encode(["success" => false, "msg" => "Invalid remoteip"]));
    }
}

if ($params["remoteport"] < 1 || $params["remoteport"] > 65535) {
    exit(json_encode(["success" => false, "msg" => "Invalid remoteport"]));
}

if (!PortForwardGo_VeifyNode($user->pid, $params['node'])) {
    exit(json_encode(["success" => false, "msg" => "Invalid node"]));
}

if (!(bool)$params['rc'] && !PortForwardGo_VeifyRemotePort($params['node'], $params["remoteport"])) {
    exit(json_encode(["success" => false, "msg" => "This remoteport isn't available"]));
}

$allow_protocol = PortForwardGo_GetAllowProtocol($user->pid, $params['node']);

if (!$allow_protocol[$params['protocol']]) {
    exit(json_encode(["success" => false, "msg" => "This protocol isn't available"]));
}

if (in_array($params['protocol'], ['http', 'https'])) {
    $is_domain = preg_match("/^(?!:\/\/)(?!.{256,})(([a-z0-9][a-z0-9_-]*?)|([a-z0-9][a-z0-9_-]*?\.)+?[a-z]{2,15}?)$/i", $params['port']);
    if (!$is_domain || preg_match("/^-?\d+$/", $params['port'])) {
        exit(json_encode(["success" => false, "msg" => "Invalid domain name"]));
    }

    if (!PortForwardGo_VeifyDomainICP($params['node'], $params['port'])) {
        exit(json_encode(["success" => false, "msg" => "There is no ICP record for this domain name"]));
    }
} else {
    if (!preg_match("/^-?\d+$/", $params['port']) || $params["port"] < 1 || $params["port"] > 65535) {
        exit(json_encode(["success" => false, "msg" => "Invalid port"]));
    }
    if (!PortForwardGo_VeifyPort($params['node'], $params["port"])) {
        exit(json_encode(["success" => false, "msg" => "This port isn't available"]));
    }
}

if (Capsule::table('mod_PortForwardGo_Users')->where('sid', $user->sid)->first()->max_rules <= Capsule::table('mod_PortForwardGo_Rules')->where('sid', $user->sid)->where('status', '!=', 'Deleted')->count()) {
    exit(json_encode(["success" => false, "msg" => "Limit reached"]));
}

if (!PortForwardGo_CheckPort($params['node'], $params['protocol'], $params['port'])) {
    exit(json_encode(["success" => false, "msg" => "This protocol (domain name) is not available"]));
}

$data = Capsule::table("mod_PortForwardGo_Node")->where('id', $params['node'])->first();
$ruleid = Capsule::table("mod_PortForwardGo_Rules")->insertGetId([
    "sid" => $user->sid,
    "port" => $params["port"],
    "remoteport" => $params["remoteport"],
    "remoteip" => $params["remoteip"],
    "protocol" => $params["protocol"],
    "proxyprotocolversion" => $params['proxyprotocolversion'],
    'rc' => (bool)$params['rc'],
    "msg" => $params['msg'],
    "node" => $params['node'],
    "status" => "Created",
]);

$info['id'] = $ruleid;
$info['connaddr'] = $data->addr;
$info['status'] = 'Created';


if ((bool)$params['rc']) {
    Capsule::table("mod_PortForwardGo_RClient_Changes")->insert(['sid' => $user->sid, 'node' => $params['node'], 'rule_id' => $ruleid, 'status' => 'Created']);
}

if (PortForwardGo_APICall($ruleid)) {
    Capsule::table("mod_PortForwardGo_Rules")->where("id", $ruleid)->update(['status' => 'Active']);
    $info['status'] = 'Active';
}

exit(json_encode(["success" => true, 'data' => $info]));
