<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

require_once(__DIR__ . '/../../addons/PortForwardGo/func.php');

use Illuminate\Database\Capsule\Manager as Capsule;


function PortForwardGoClient_MetaData()
{
    return array(
        'DisplayName' => 'PortForwardGo',
        'APIVersion' => '1.1',
        'RequiresServer' => false,
    );
}

function PortForwardGoClient_ConfigOptions()
{
    if (basename($_SERVER['PHP_SELF']) == 'configaddons.php') {
        return  array(
            '额外流量' => array(
                'Type' => 'text',
                'Description' => 'GB (0为不增加)',
            ),
            '额外速率' => array(
                'Type' => 'text',
                'Description' => 'Mbps (0为不增加)',
            ),
        );
    } else {
        $plans = [];
        $plans_sql = Capsule::table('mod_PortForwardGo_Plans')->get();
        foreach ($plans_sql as $plan) {
            $plans[$plan->id] = $plan->name;
        }

        return array(
            '产品套餐' => array(
                'Type' => 'dropdown',
                'Options' => $plans,
            ),
        );
    }
}

function PortForwardGoClient_CreateAccount(array $params)
{
    if ($params['addonId'] == 0) {
        if (Capsule::table('mod_PortForwardGo_Users')->where('sid', $params['serviceid'])->exists()) {
            return '服务已存在！请勿重复开通';
        }

        $plan = Capsule::table('mod_PortForwardGo_Plans')->where('id', $params['configoption1'])->first();

        Capsule::table('mod_PortForwardGo_Users')->insert([
            'sid' => $params['serviceid'],
            'pid' => $params['configoption1'],
            'max_rules' => $plan->rules,
            'traffic' => $plan->traffic,
            'traffic_used' => 0,
            'speed' => $plan->speed,
            'max_conn' => $plan->conn,
        ]);
        Capsule::table('mod_PortForwardGo_Services')->insert([
            'sid' => $params['serviceid'],
            'restdate' => date("Y-m-d", strtotime("+1 month")),
        ]);
        return 'success';
    } else {
        if (!Capsule::table('mod_PortForwardGo_Users')->where('sid', $params['serviceid'])->exists()) {
            return '服务不存在！';
        }

        $data = Capsule::table('mod_PortForwardGo_Users')->where('sid', $params['serviceid'])->first();
        if ($data->speed == 0) {
            Capsule::table('mod_PortForwardGo_Users')->where('sid', $params['serviceid'])->update(['traffic' => $data->traffic + ($params['configoption1'] * 1073741824)]);
        } else {
            Capsule::table('mod_PortForwardGo_Users')->where('sid', $params['serviceid'])->update(['traffic' => $data->traffic + ($params['configoption1'] * 1073741824), 'speed' => $data->speed + $params['configoption2']]);
        }
        Capsule::table('mod_PortForwardGo_Rules')->where('sid', $params['serviceid'])->update(['status' => 'Active']);
        return 'success';
    }
}

function PortForwardGoClient_SuspendAccount(array $params)
{
    if ($params['addonId'] == 0) {
        if (!Capsule::table('mod_PortForwardGo_Users')->where('sid', $params['serviceid'])->exists()) {
            return '服务不存在！';
        }
        Capsule::table('mod_PortForwardGo_Rules')->where('sid', $params['serviceid'])->update(['status' => 'Suspend']);
    }
    return 'success';
}


function PortForwardGoClient_UnsuspendAccount(array $params)
{
    if ($params['addonId'] == 0) {
        if (!Capsule::table('mod_PortForwardGo_Users')->where('sid', $params['serviceid'])->exists()) {
            return '服务不存在！';
        }

        Capsule::table('mod_PortForwardGo_Rules')->where('sid', $params['serviceid'])->update(['status' => 'Active']);
    }
    return 'success';
}


function PortForwardGoClient_TerminateAccount(array $params)
{
    if ($params['addonId'] == 0) {

        if (!Capsule::table('mod_PortForwardGo_Users')->where('sid', $params['serviceid'])->exists()) {
            return '服务不存在！';
        }
        Capsule::table('mod_PortForwardGo_Rules')->where('sid', $params['serviceid'])->update([
            'status' => "Deleted",
        ]);
        Capsule::table('mod_PortForwardGo_Users')->where('sid', $params['serviceid'])->delete();
        Capsule::table('mod_PortForwardGo_Services')->where('sid', $params['serviceid'])->delete();
        return 'success';
    } else {
        if (!Capsule::table('mod_PortForwardGo_Users')->where('sid', $params['serviceid'])->exists()) {
            return 'success';
        }

        $data = Capsule::table('mod_PortForwardGo_Users')->where('sid', $params['serviceid'])->first();
        $traffic_used = 0;
        if ($data->traffic_used > ($params['configoption1'] * 1073741824)) {
            $traffic_used = $data->traffic_used - ($params['configoption1'] * 1073741824);
        }
        if ($data->speed == 0) {
            Capsule::table('mod_PortForwardGo_Users')->where('sid', $params['serviceid'])->update(['traffic' => $data->traffic - ($params['configoption1'] * 1073741824), 'traffic_used' => $traffic_used]);
        } else {
            Capsule::table('mod_PortForwardGo_Users')->where('sid', $params['serviceid'])->update(['traffic' => $data->traffic - ($params['configoption1'] * 1073741824), 'speed' => $data->speed - $params['configoption2'], 'traffic_used' => $traffic_used]);
        }
        return 'success';
    }
}

function PortForwardGoClient_ChangePackage(array $params)
{
    if ($params['addonId'] == 0) {
        if (!Capsule::table('mod_PortForwardGo_Users')->where('sid', $params['serviceid'])->exists()) {
            return '服务不存在';
        }

        $plan = Capsule::table('mod_PortForwardGo_Plans')->where('id', $params['configoption1'])->first();

        Capsule::table('mod_PortForwardGo_Users')->where('sid', $params['serviceid'])->update([
            'pid' => $params['configoption1'],
            'max_rules' => $plan->rules,
            'traffic' => $plan->traffic,
            'speed' => $plan->speed,
        ]);

        return 'success';
    } else {
        return '扩展服务不支持更改套餐,请终止后选择正确的套餐重新开通';
    }
}

function PortForwardGoClient_AdminCustomButtonArray()
{
    return array(
        "重置流量" => "resetTraffic",
    );
}


function PortForwardGoClient_resetTraffic(array $params)
{
    if (!Capsule::table('mod_PortForwardGo_Users')->where('sid', $params['serviceid'])->exists()) {
        return '服务不存在！';
    }

    Capsule::table('mod_PortForwardGo_Users')->where('sid', $params['serviceid'])->update(['traffic_used' => 0]);

    return 'success';
}

function PortForwardGoClient_AdminServicesTabFields(array $params)
{
    $html = <<<HTML
<a class="btn btn-default" onClick="window.open('addonmodules.php?module=PortForwardGo&page=users&sid={$params['serviceid']}','target','');">高级管理</a>
HTML;
    return array('服务管理' => $html);
}

function PortForwardGoClient_ClientArea(array $params)
{

    if (isset($_REQUEST['page']) && file_exists(__DIR__ . '/templates/' . $_REQUEST['page'] . '.tpl')) {
        return [
            'tabOverviewReplacementTemplate' =>  'templates/' . $_REQUEST['page'] . '.tpl'
        ];
    }

    if ($params['status'] != 'Active') {
        return array(
            'tabOverviewReplacementTemplate' => 'templates/error.tpl',
            'vars' => array(
                'text' => '您的产品未激活',
            ),
        );
    }

    if (!Capsule::table('mod_PortForwardGo_Users')->where('sid', $params['serviceid'])->exists()) {
        return array(
            'tabOverviewReplacementTemplate' => 'templates/error.tpl',
            'vars' => array(
                'text' => '服务不存在！',
            ),
        );
    }

    if (isset($_REQUEST['a']) && file_exists(__DIR__ . '/action/' . $_REQUEST['a'] . '.php')) {
        require_once(__DIR__ . '/action/' . $_REQUEST['a'] . '.php');
        exit();
    }

    $user = Capsule::table('mod_PortForwardGo_Users')->where('sid', $params['serviceid'])->first();
    $rules = Capsule::table('mod_PortForwardGo_Rules')->where('sid', $params['serviceid'])->where('status', '!=', 'Deleted')->get();
    $info = array(
        'system_url' => PortForwardGo_GetSystemURL(),
        'now_rule' => Capsule::table('mod_PortForwardGo_Rules')->where('sid', $params['serviceid'])->where('status', '!=', 'Deleted')->count(),
    );

    $plan = Capsule::table('mod_PortForwardGo_Plans')->where('id', $user->pid)->first();

    $available_nodes = explode('|', $plan->node);
    $nodes = Capsule::table('mod_PortForwardGo_Node')->get();

    foreach ($nodes as $n) {
        if (in_array($n->id, $available_nodes)) {
            $support_nodes[$n->id] = $n;
        }
    }
    foreach ($nodes as $n) {
        $all_nodes[$n->id] = $n;
    }

    $all_protocols = PortForwardGo_AllProtocol();
    $support_protocols = $all_protocols;
    $tunnel_protocols = PortForwardGo_AllTunnelProtocol();

    $avaiilable_protocols = json_decode($plan->protocol, true);

    foreach ($avaiilable_protocols as $name => $value) {
        if (!$value) {
            unset($support_protocols[$name]);
            unset($tunnel_protocols[$name]);
        }
    }

    return array(
        'tabOverviewReplacementTemplate' => 'templates/clientarea.tpl',
        'vars' => array(
            'info' => $info,
            'rules' => $rules,
            'user' => $user,

            'all_nodes' => $all_nodes,
            'nodes' => $support_nodes,

            'all_protocols' => $all_protocols,
            'protocols' => $support_protocols,
            'tunnel_protocols' => $tunnel_protocols,
            'rc' => [0 => '否', 1 => '是'],

            'proxyprotocolversions' => PortForwardGo_AllProxyProtocolVersion(),
            'status' => PortForwardGo_StatusArray(),

            'restdate' => Capsule::table('mod_PortForwardGo_Services')->where('sid', $params['serviceid'])->first()->restdate,
        ),
    );
}
