<?php
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

set_time_limit(0);
require_once __DIR__ . "/../../../init.php";

use Illuminate\Database\Capsule\Manager as Capsule;

function PortForwardGo_GetConfigModule()
{
    $AddonModuleConfig = Capsule::table('mod_PortForwardGo_Setting')->get();
    $config            = [];

    for ($i = 0; $i < count($AddonModuleConfig); $i++) //var_dump($vars);
    {
        $config[$AddonModuleConfig[$i]->name] = $AddonModuleConfig[$i]->value;
    }

    return $config;
}

function PortForwardGo_GetSystemURL()
{
    return rtrim(Capsule::table('tblconfiguration')->where('setting', '=', 'SystemURL')->first()->value, '/') . '/';
}

function PortForwardGo_AllProtocol()
{
    return [
        'tcp' => 'TCP',
        'udp' => 'UDP',
        'http' => 'HTTP',
        'https' => 'HTTPS',
        'ws' => 'WS隧道(服务端)',
        'wsc' => 'WS隧道(客户端)',
        'wss' => 'WSS隧道(服务端)',
        'wssc' => 'WSS隧道(客户端)',
        'stcp' => 'STCP隧道(服务端)',
        'stcpc' => 'STCP隧道(客户端)',
        'sudp' => 'SUDP隧道(服务端)',
        'sudpc' => 'SUDP隧道(客户端)',
    ];
}


function PortForwardGo_AllTunnelProtocol()
{
    return [
        'ws' => 'WebSocket',
        'wss' => 'WebSocket TLS',
        'stcp' => 'STCP',
        'sudp' => 'SUDP',
    ];
}

function PortForwardGo_AllProxyProtocolVersion()
{
    return [
        0 => "关闭",
        1 => "v1",
        2 => "v2",
    ];
}

function PortForwardGo_PrintText(bool $is_success, $text)
{
    if ($is_success) {
        echo '<div class="col-sm-6 col-sm-offset-3"><div class="alert alert-success">' . $text . '</div></div>';
    } else {
        echo '<div class="col-sm-6 col-sm-offset-3"><div class="alert alert-danger">' . $text . '</div></div>';
    }
}

function PortForwardGo_inittable()
{
    PortForwardGo_droptable();
    try {
        Capsule::schema()->create("mod_PortForwardGo_Setting", function ($table) {
            $table->increments('id');
            $table->string('name');
            $table->string('value')->default("");
        });
    } catch (\Exception $e) {
        return [
            'status'        =>  'error',
            'description'   =>  "无法创建表 'mod_PortForwardGo_Setting' : {$e->getMessage()}"
        ];
    }

    try {
        Capsule::schema()->create("mod_PortForwardGo_Node", function ($table) {
            $table->increments('id');
            $table->string('name')->default("");
            $table->string('addr')->default("");
            $table->boolean('api')->default(false);
            $table->integer('apiport')->default(0);
            $table->integer('rc_tcp_port')->default(7000);
            $table->integer('rc_kcp_port')->default(7000);
            $table->string('retain_remoteport')->default("");
            $table->string('retain_port')->default("");
            $table->string('protocol')->default("{}");
            $table->string('speed_times')->default("1");
            $table->string('traffic_times')->default("1");
            $table->integer('cron')->default(300);
            $table->integer('http_port')->default(80);
            $table->integer('http_port_2')->default(8080);
            $table->integer('https_port')->default(443);
            $table->integer('https_port_2')->default(8443);
            $table->boolean('icp')->default(false);
            $table->datetime('updated')->default("0000-00-00 00:00:00");
            $table->string('description')->default("");
        });
    } catch (\Exception $e) {
        return [
            'status'        =>  'error',
            'description'   =>  "无法创建表 'mod_PortForwardGo_Node' : {$e->getMessage()}"
        ];
    }

    try {
        Capsule::schema()->create("mod_PortForwardGo_Rules", function ($table) {
            $table->increments('id');
            $table->integer('sid')->default(0);
            $table->string('protocol')->default("");
            $table->integer('proxyprotocolversion')->default(0);
            $table->boolean('rc')->default(false);
            $table->string('remoteip')->default("");
            $table->string('remoteport')->default("");
            $table->string('port')->default("");
            $table->integer('node')->default(0);
            $table->string('msg')->default("");
            $table->string('status')->default("Created");
        });
    } catch (\Exception $e) {
        return [
            'status'        =>  'error',
            'description'   =>  "无法创建表 'mod_PortForwardGo_Rules' : {$e->getMessage()}"
        ];
    }

    try {
        Capsule::schema()->create("mod_PortForwardGo_RClient_Changes", function ($table) {
            $table->increments('id');
            $table->integer('sid');
            $table->integer('node');
            $table->integer('rule_id');
            $table->string('status');
        });
    } catch (\Exception $e) {
        return [
            'status'        =>  'error',
            'description'   =>  "无法创建表 'mod_PortForwardGo_RClient_Changes' : {$e->getMessage()}"
        ];
    }

    try {
        Capsule::schema()->create("mod_PortForwardGo_Users", function ($table) {
            $table->increments('id');
            $table->integer('sid')->default(0);
            $table->integer('pid')->default(0);
            $table->integer('max_rules')->default(0);
            $table->biginteger('speed')->default(0);
            $table->biginteger('max_conn')->default(0);
            $table->biginteger('traffic')->default(0);
            $table->biginteger('traffic_used')->default(0);
            $table->string('api')->default("disabled");
        });
    } catch (\Exception $e) {
        return [
            'status'        =>  'error',
            'description'   =>  "无法创建表 'mod_PortForwardGo_Users' : {$e->getMessage()}"
        ];
    }

    try {
        Capsule::schema()->create("mod_PortForwardGo_Plans", function ($table) {
            $table->increments('id');
            $table->string('name')->default("");
            $table->string('node')->default("");
            $table->string('protocol')->default("{}");
            $table->integer('rules')->default(0);
            $table->biginteger('traffic')->default(0);
            $table->biginteger('speed')->default(0);
            $table->integer('conn')->default(0);
        });
    } catch (\Exception $e) {
        return [
            'status'        =>  'error',
            'description'   =>  "无法创建表 'mod_PortForwardGo_Plans' : {$e->getMessage()}"
        ];
    }

    try {
        Capsule::schema()->create("mod_PortForwardGo_Services", function ($table) {
            $table->increments('id');
            $table->integer('sid');
            $table->date('restdate');
        });
    } catch (\Exception $e) {
        return [
            'status'        =>  'error',
            'description'   =>  "无法创建表 'mod_PortForwardGo_Services' : {$e->getMessage()}"
        ];
    }

    try {
        Capsule::schema()->create("mod_PortForwardGo_Info", function ($table) {
            $table->increments('id');
            $table->string('name');
            $table->string('value');
        });
    } catch (\Exception $e) {
        return [
            'status'        =>  'error',
            'description'   =>  "无法创建表 'mod_PortForwardGo_Info' : {$e->getMessage()}"
        ];
    }

    try {

        Capsule::table('mod_PortForwardGo_Setting')->insert(['name' => 'key', 'value' => '']);
        Capsule::table('mod_PortForwardGo_Setting')->insert(['name' => 'clientarea', 'value' => 'off']);
        Capsule::table('mod_PortForwardGo_Info')->insert(['name' => 'today_traffic', 'value' => '0']);
        Capsule::table('mod_PortForwardGo_Info')->insert(['name' => 'month_traffic', 'value' => '0']);
    } catch (\Exception $e) {
        return [
            'status'        =>  'error',
            'description'   =>  "{$e->getMessage()}"
        ];
    }
}

function PortForwardGo_droptable()
{
    Capsule::schema()->dropIfExists('mod_PortForwardGo_Setting');
    Capsule::schema()->dropIfExists('mod_PortForwardGo_Info');
    Capsule::schema()->dropIfExists('mod_PortForwardGo_Node');
    Capsule::schema()->dropIfExists('mod_PortForwardGo_Users');
    Capsule::schema()->dropIfExists('mod_PortForwardGo_Rules');
    Capsule::schema()->dropIfExists('mod_PortForwardGo_Plans');
    Capsule::schema()->dropIfExists('mod_PortForwardGo_Services');
    Capsule::schema()->dropIfExists('mod_PortForwardGo_RClient_Changes');
}


function PortForwardGo_GetAllowProtocol(int $planid, int $nodeid)
{
    $protocols = json_decode(Capsule::table('mod_PortForwardGo_Node')->where('id', $nodeid)->first()->protocol, true);
    $plans = json_decode(Capsule::table('mod_PortForwardGo_Plans')->where('id', $planid)->first()->protocol, true);
    foreach ($plans as $protocol => $value) {
        if (!$value) {
            $protocols[$protocol] = false;
        }
    }

    return $protocols;
}


function PortForwardGo_CheckPort(int $nodeid, string $protocol, string $port)
{
    $port = strtolower($port);
    if (in_array($protocol, ['http', 'https'])) {
        $addr = Capsule::table('mod_PortForwardGo_Node')->where('id', $nodeid)->first()->addr;
        if ($port == strtolower($addr)) {
            return false;
        }
    }

    $pgs =
        [
            ["tcp", "ws", "wsc", "wss", "wssc", "stcp", "stcpc"],
            ["udp", "sudp", "sudpc"],
        ];

    foreach ($pgs as $pg) {
        if (in_array($protocol, $pg)) {
            if (Capsule::table('mod_PortForwardGo_Rules')->where('node', $nodeid)->whereIn('protocol', $pg)->where('port', $port)->exists()) {
                return false;
            }
        }
    }
    return !Capsule::table('mod_PortForwardGo_Rules')->where('node', $nodeid)->where('protocol', $protocol)->where('port', $port)->exists();
}

function PortForwardGo_VeifyPort(int $nodeid, int $port)
{
    $nodeinfo = Capsule::table('mod_PortForwardGo_Node')->where('id', $nodeid)->first();
    $retain_ports = explode(PHP_EOL, $nodeinfo->retain_port);

    if (!is_array($retain_ports)) {
        $retain_ports[0] = $nodeinfo->retain_port;
    }

    array_push($retain_ports, $nodeinfo->apiport);
    array_push($retain_ports, $nodeinfo->rc_tcp_port);
    array_push($retain_ports, $nodeinfo->rc_kcp_port);

    array_push($retain_ports, $nodeinfo->http_port);
    if ($nodeinfo->http_port != $nodeinfo->http_port_2 && $nodeinfo->http_port_2 != 0) {
        array_push($retain_ports, $nodeinfo->http_port_2);
    }
    array_push($retain_ports, $nodeinfo->https_port);
    if ($nodeinfo->https_port != $nodeinfo->https_port_2 && $nodeinfo->https_port_2 != 0) {
        array_push($retain_ports, $nodeinfo->https_port_2);
    }
    foreach ($retain_ports as $retain_port) {
        if (strpos($retain_port, '-') != false) {
            $firstport = explode('-', $retain_port)[0];
            $lastport = explode('-', $retain_port)[1];
            if ($port >= $firstport && $port <= $lastport) {
                return false;
            }
        } else {
            if ($port == $retain_port) {
                return false;
            }
        }
    }
    return true;
}

function PortForwardGo_VeifyRemotePort(int $nodeid, int $port)
{
    $nodeinfo = Capsule::table('mod_PortForwardGo_Node')->where('id', $nodeid)->first();
    $retain_ports = explode(PHP_EOL, $nodeinfo->retain_remoteport);

    if (!is_array($retain_ports)) {
        $retain_ports[0] = $nodeinfo->retain_remoteport;
    }

    foreach ($retain_ports as $retain_port) {
        if (strpos($retain_port, '-') != false) {
            $firstport = explode('-', $retain_port)[0];
            $lastport = explode('-', $retain_port)[1];
            if ($port >= $firstport && $port <= $lastport) {
                return false;
            }
        } else {
            if ($port == $retain_port) {
                return false;
            }
        }
    }
    return true;
}

function PortForwardGo_VeifyNode(int $planid, int $nodeid)
{
    $nodes = explode('|', Capsule::table('mod_PortForwardGo_Plans')->where('id', $planid)->first()->node);
    if (in_array($nodeid, $nodes)) {
        return true;
    } else {
        return false;
    }
}

function PortForwardGo_StatusArray()
{
    return [
        "Created" => '<a style="color:blue;">创建中...</a>',
        "Disabled" => '<a style="color:#999999;">停用</a>',
        "Suspend" => '<a style="color:orange;">已暂停</a>',
        "Active" => '<a style="color:green;">正常</a>',
        "Deleted" => '<a style="color:red;">删除中...</a>',
        "Error" => '<a style="color:red;">创建失败</a>',
        "Exhaust" => '<a style="color:red;">超流量</a>',
    ];
}

function PortForwardGo_httprequest($url, $data = null, $header = null)
{
    $curl = curl_init();
    if (!empty($header)) {
        curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
        curl_setopt($curl, CURLOPT_HEADER, 0); //返回response头部信息
    }
    curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 30);
    curl_setopt($curl, CURLOPT_TIMEOUT, 60);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    if (!empty($data)) {
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    }

    curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
    $output = curl_exec($curl);
    curl_close($curl);
    return $output;
}

function PortForwardGo_APICall(int $ruleid)
{
    $rule = Capsule::table('mod_PortForwardGo_Rules')->where('id', $ruleid)->first();

    $sql = Capsule::table('mod_PortForwardGo_Node')->where('id', $rule->node)->first();
    if (!$sql->api) {
        return false;
    }
    $traffic_times = $sql->traffic_times;
    $speed_times = $sql->speed_times;
    $user = Capsule::table('mod_PortForwardGo_Users')->where('sid', $rule->sid)->first();

    $postdata[(string)$ruleid]['Status'] = $rule->status;
    $postdata[(string)$ruleid]['UID'] = (string)$rule->sid;
    $postdata[(string)$ruleid]['Protocol'] = $rule->protocol;
    $postdata[(string)$ruleid]['ProxyProtocolVersion'] = $rule->proxyprotocolversion;
    $postdata[(string)$ruleid]['Listen'] = $rule->port;
    $postdata[(string)$ruleid]['RemoteHost'] = $rule->remoteip;
    $postdata[(string)$ruleid]['RemotePort'] = (int)$rule->remoteport;
    $postdata[(string)$ruleid]['Speed'] = ceil($user->speed * $speed_times);
    $postdata[(string)$ruleid]['MaxConn'] = $user->max_conn;

    if ($user->traffic > $user->traffic_used) {
        if ($traffic_times > 0) {
            $postdata[(string)$ruleid]['Quota'] = ceil($user->traffic / $traffic_times);
        } else {
            $postdata[(string)$ruleid]['Quota'] = 9223372036854775807;
        }
    } else {
        $postdata[(string)$ruleid]['Quota'] = 0;
    }

    $path =  md5(Capsule::table('mod_PortForwardGo_Setting')->where('name', 'key')->first()->value);

    $url = 'http://' . $sql->addr . ':' . $sql->apiport . '/api/v2/' . $path . '/sync';
    return json_decode(PortForwardGo_httprequest($url, json_encode($postdata)), true)['Result'];
}

function PortForwardGo_VeifyDomainICP(int $nodeid, string $dm)
{
    $data = Capsule::table("mod_PortForwardGo_Node")->where('id', $nodeid)->first();
    if (!(bool)$data->icp) {
        return true;
    }
    $json = json_decode(PortForwardGo_httprequest("http://api.btstu.cn/icp/api.php?domain=" . $dm), true);
    if ($json['code'] == "200") {
        return true;
    } else {
        return false;
    }
    return false;
}

function PortForwardGo_CheckUser($serviceid)
{
    $user = Capsule::table('mod_PortForwardGo_Users')->where('sid', $serviceid);
    if (!$user->exists()) {
        return false;
    }
    $user = $user->first();
    if ($user->traffic_used >= $user->traffic) {
        return false;
    }
    return true;
}

function PortForwardGo_UpdateStatus()
{
    $users = Capsule::table('mod_PortForwardGo_Users')->get();
    foreach ($users as $user) {
        if ($user->traffic_used >= $user->traffic) {
            Capsule::table("mod_PortForwardGo_Rules")->where('sid', $user->sid)->where('status', '!=', 'Deleted')->where('status', '!=', 'Suspend')->where('status', '!=', 'Exhaust')->update(['status' => 'Exhaust']);
        } else {
            Capsule::table("mod_PortForwardGo_Rules")->where('sid', $user->sid)->where('status', 'Exhaust')->update(['status' => 'Active']);
        }
    }
}

function PortForwardGo_CreateToken(int $long)
{
    $salt = "abcdefghijklmnpqrstuvwxyzABCDEFGHIJKLMNPQRSTUVWXYZ123456789";
    srand((float)microtime() * 1000000); // 启动随机产生器
    $Spass = ""; // 设置初始值
    for ($i = 0; $i < $long; $i++) { // 循环创建密码
        $Spass = $Spass . substr($salt, rand() % strlen($salt), 1);
    }
    return $Spass;
}
