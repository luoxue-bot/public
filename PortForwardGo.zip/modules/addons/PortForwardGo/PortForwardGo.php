<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use Illuminate\Database\Capsule\Manager as Capsule;

require_once __DIR__ . '/func.php';
require_once __DIR__ . '/version.php';
require_once __DIR__ . '/ajax.php';

function PortForwardGo_config()
{
    global $version;
    return [
        "name" => "PortForwardGo",
        "description" => "PortForwardGO - 适用于WHMCS的嵌入式插件",
        "version" => $version,
        "author" => "ZeroTime Team",
    ];
}

function PortForwardGo_activate()
{
    PortForwardGo_inittable();
}

function PortForwardGo_deactivate()
{
    PortForwardGo_droptable();
}


function PortForwardGo_output($vars)
{
    global $version;

    if (isset($_REQUEST['ajax'])) {
        $funcname = "PortForwardGo_Ajax_" . $_REQUEST['ajax'];
        $funcname();
        exit;
    }

    if (isset($_REQUEST['do']) && file_exists(__DIR__ . '/templates/admin/' . $_REQUEST['page'] . '.php')) {
        include(__DIR__ . '/templates/admin/' . $_REQUEST['page'] . '.php');
        exit();
    }

    if (isset($_REQUEST['page']) && file_exists(__DIR__ . '/templates/admin/' . $_REQUEST['page'] . '.php')) {
        $active[$_REQUEST['page']] = 'active';
    } else {
        $active['view'] = 'active';
    }

    include_once(__DIR__ . '/templates/admin/header.php');
    if (isset($_REQUEST['page']) && file_exists(__DIR__ . '/templates/admin/' . $_REQUEST['page'] . '.php')) {
        if (isset($_REQUEST['a']) && file_exists(__DIR__ . '/action/' . $_REQUEST['a'] . '/' . $_REQUEST['page'] . '.php')) {
            include_once(__DIR__ . '/action/' . $_REQUEST['a'] . '/' . $_REQUEST['page'] . '.php');
            if (in_array($_REQUEST['a'], ['delete', 'save', 'clean'])) {
                echo '<meta http-equiv="refresh" content="5;url=?module=PortForwardGo&page=' . $_REQUEST['page'] . '">';
            }
        } else {
            include_once(__DIR__ . '/templates/admin/' . $_REQUEST['page'] . '.php');
        }
    } else {
        include_once(__DIR__ . '/templates/admin/view.php');
    }
    include_once(__DIR__ . '/templates/admin/footer.php');
}


function PortForwardGo_clientarea($vars)
{
    if (!isset($_REQUEST['type'])) {
        return array(
            'pagetitle' => '端口转发 - 信息查询',
            'templatefile' => 'templates/clientarea/home.tpl',
            'vars' => array(
                'plans' => Capsule::table("mod_PortForwardGo_Plans")->get(),
                'nodes' => Capsule::table("mod_PortForwardGo_Node")->get(),
            ),
        );
    }
    switch ($_REQUEST['type']) {
        case "node":
            $node = Capsule::table("mod_PortForwardGo_Node")->where('id', $_REQUEST['id'])->first();
            return array(
                'pagetitle' => '端口转发 - 节点信息',
                'templatefile' => 'templates/clientarea/node.tpl',
                'vars' => array(
                    'node' => $node,
                    'node_protocols' => json_decode($node->protocol, true),
                    'protocols' => PortForwardGo_AllProtocol(),
                    'retain_remoteport' => explode(PHP_EOL, $node->retain_remoteport),
                    'retain_port' => explode(PHP_EOL, $node->retain_port),
                ),
            );
        case "plan":
            $plan = Capsule::table("mod_PortForwardGo_Plans")->where('id', $_REQUEST['id'])->first();
            foreach (Capsule::table('mod_PortForwardGo_Node')->get() as $node) {
                $nodes[$node->id] = $node;
            }
            return array(
                'pagetitle' => '端口转发 - 套餐信息',
                'templatefile' => 'templates/clientarea/plan.tpl',
                'vars' => array(
                    'plan_protocols' => json_decode($plan->protocol, true),
                    'protocols' => PortForwardGo_AllProtocol(),
                    'plan' => $plan,
                    'nodes' => $nodes,
                    'plan_nodes' => explode("|", $plan->node),
                ),
            );
    }
}
