<?php
use Illuminate\Database\Capsule\Manager as Capsule;
if(isset($_REQUEST['id'])){
    if(Capsule::table('mod_PortForwardGo_Plans')->where('id',$_REQUEST['id'])->exists()){
        if(Capsule::table('mod_PortForwardGo_Users')->where('pid',$_REQUEST['id'])->exists()){
            PortForwardGo_PrintText(false,"有用户正在使用此套餐，无法将其删除");
        }else{
        Capsule::table('mod_PortForwardGo_Plans')->where('id',$_REQUEST['id'])->delete();
        PortForwardGo_PrintText(true,'套餐删除成功');
        }
    }else{
        PortForwardGo_PrintText(false,'套餐不存在');
    }
}else{
    PortForwardGo_PrintText(false,'请求参数缺失');
}