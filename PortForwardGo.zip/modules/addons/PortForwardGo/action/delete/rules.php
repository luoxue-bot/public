<?php

use Illuminate\Database\Capsule\Manager as Capsule;

if (isset($_REQUEST['id'])) {
    $sql = Capsule::table('mod_PortForwardGo_Rules')->where('id', $_REQUEST['id']);
    if ($sql->exists()) {
        $info = $sql->first();
        if ($info->status == "Created") {
            if ((bool)$info->rc) {
                Capsule::table("mod_PortForwardGo_RClient_Changes")->where("rule_id", $info->id)->delete();
            }
            $sql->delete();
        } else {
            $sql->update(['status' => 'Deleted']);
            if ((bool)$data->rc) {
                $sql = Capsule::table("mod_PortForwardGo_RClient_Changes")->where('node', $info->node)->where('rule_id', $info->id);
                if ($sql->exists()) {
                    $sql->delete();
                } else {
                    Capsule::table("mod_PortForwardGo_RClient_Changes")->insert(['sid' => $info->sid, 'node' => $info->node, 'rule_id' => $info->id, 'status' => 'Deleted']);
                }
            }
            if (PortForwardGo_APICall($info->id)) {
                $sql->delete();
            }
        }
        PortForwardGo_PrintText(true, '规则删除成功');
    } else {
        PortForwardGo_PrintText(false, '规则不存在');
    }
} else {
    PortForwardGo_PrintText(false, '请求参数缺失');
}
