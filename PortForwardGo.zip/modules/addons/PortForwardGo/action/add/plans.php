<?php

use Illuminate\Database\Capsule\Manager as Capsule;

$nodes = Capsule::table('mod_PortForwardGo_Node')->get();
$protocols = PortForwardGo_AllProtocol();
?>
<h1>添加</h1>
<input type="hidden" name="a" value="save">
<input type="hidden" name="page" value="<?php echo $_REQUEST['page']; ?>">
<table class="form" width="100%" border="0" cellspacing="2" cellpadding="3">
    <tbody>
        <tr>
            <td class="fieldlabel">名称</td>
            <td class="fieldarea"><input type="text" name="name" class="form-control input-inline input-400" required></td>
        </tr>

        <tr>
            <td class="fieldlabel">可用节点</td>
            <td class="fieldarea">
                <select id="node" name="node[]" multiple="multiple">
                    <?php foreach ($nodes as $node) { ?>
                        　　　　 <option value="<?php echo $node->id; ?>"><?php echo $node->name; ?></option>
                    <?php } ?>
                </select>
            </td>
        </tr>

        <tr>
            <td class="fieldlabel">转发规则</td>
            <td class="fieldarea"><input type="number" min="1" name="rules" class="form-control input-inline input-400" required>条</td>
        </tr>

        <tr>
            <td class="fieldlabel">流量</td>
            <td class="fieldarea"><input type="number" min="1" name="traffic" class="form-control input-inline input-400" required>GB</td>
        </tr>

        <tr>
            <td class="fieldlabel">速率</td>
            <td class="fieldarea"><input type="number" min="0" name="speed" class="form-control input-inline input-400" required>Mbps（不限制为0）</td>
        </tr>

        <tr>
            <td class="fieldlabel">连接数</td>
            <td class="fieldarea"><input type="number" min="0" name="conn" class="form-control input-inline input-400" required>个（不限制为0）</td>
        </tr>

        <tr>
            <td width="20%" class="fieldlabel">可用协议</td>
            <td class="fieldarea">
                <?php foreach ($protocols as $protocol => $value) { ?>
                    <input type="checkbox" name="protocol[<?php echo $protocol; ?>]"><?php echo $value; ?>
                    <br>
                <?php } ?>
            </td>
        </tr》

    </tbody>
</table>

<div align="center">
    <button type="submit" class="btn btn-success text-center"><i class="md md-assignment-turned-in"></i>提交</button>
    <button type="button" class="btn btn-default text-center" onClick='window.location.href="?module=PortForwardGo&page=<?php echo $_REQUEST['page']; ?>"'><i class="md md-assignment-turned-in"></i>取消</button>
</div>

<script type="text/javascript">
    $(function() {
        $("#node").fSelect();
    });
</script>