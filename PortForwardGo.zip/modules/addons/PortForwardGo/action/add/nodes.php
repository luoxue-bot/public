<?php

use Illuminate\Database\Capsule\Manager as Capsule;

$plans = Capsule::table('mod_PortForwardGo_Plans')->get();
$protocols = PortForwardGo_AllProtocol();
?>
<h1>添加</h1>
<input type="hidden" name="a" value="save">
<input type="hidden" name="page" value="<?php echo $_REQUEST['page']; ?>">
<table class="form" width="100%" border="0" cellspacing="2" cellpadding="3">
    <tbody>
        <tr>
            <td class="fieldlabel">名称</td>
            <td class="fieldarea"><input type="text" name="name" class="form-control input-inline input-400" required></td>
        </tr>

        <tr>
            <td class="fieldlabel">节点地址</td>
            <td class="fieldarea"><input type="text" name="addr" class="form-control input-inline input-400" required onkeyup="this.value=this.value.toLowerCase()" placeholder="example.com">域名或IP</td>
        </tr>

        <tr>
            <td width="20%" class="fieldlabel">API即时通知</td>
            <td class="fieldarea">
                <label class="checkbox-inline">
                    <input type="checkbox" name="api"> 通过API主动通知节点
                </label>
            </td>
        </tr>

        <tr>
            <td class="fieldlabel">API端口</td>
            <td class="fieldarea"><input type="number" min="1" max="65535" name="apiport" class="form-control input-inline input-400" placeholder="233" required></td>
        </tr>

        <tr>
            <td class="fieldlabel">内网穿透 TCP连接端口</td>
            <td class="fieldarea"><input type="number" min="0" max="65535" name="rc_tcp_port" class="form-control input-inline input-400" placeholder="7000" required>写0为关闭</td>
        </tr>

        <tr>
            <td class="fieldlabel">内网穿透 KCP(UDP)连接端口</td>
            <td class="fieldarea"><input type="number" min="0" max="65535" name="rc_kcp_port" class="form-control input-inline input-400" placeholder="7000" required>写0为关闭</td>
        </tr>

        <tr>
            <td class="fieldlabel">HTTP端口</td>
            <td class="fieldarea"><input type="number" min="1" max="65535" name="http_port" class="form-control input-inline input-400" placeholder="80" required>如果节点启用了HTTP协议，则监听此端口</td>
        </tr>

        <tr>
            <td class="fieldlabel">HTTP端口2</td>
            <td class="fieldarea"><input type="number" min="0" max="65535" name="http_port_2" class="form-control input-inline input-400" placeholder="8080" required>和HTTP端口一样(也可以写0)则无视此配置</td>
        </tr>

        <tr>
            <td class="fieldlabel">HTTPS端口</td>
            <td class="fieldarea"><input type="number" min="1" max="65535" name="https_port" class="form-control input-inline input-400" placeholder="443" required>如果节点启用了HTTPS协议，则监听此端口</td>
        </tr>

        <tr>
            <td class="fieldlabel">HTTPS端口2</td>
            <td class="fieldarea"><input type="number" min="0" max="65535" name="https_port_2" class="form-control input-inline input-400" placeholder="8443" required>和HTTPS端口一样(也可以写0)则无视此配置</td>
        </tr>

        <tr>
            <td class="fieldlabel">可用套餐</td>
            <td class="fieldarea">
                <select id="plan" name="plan[]" multiple="multiple">
                    <?php foreach ($plans as $plan) { ?>
                        <option value="<?php echo $plan->id; ?>"><?php echo $plan->name; ?></option>
                    <?php } ?>
                </select>
            </td>
        </tr>

        <tr>
            <td width="20%" class="fieldlabel">域名ICP备案检测</td>
            <td class="fieldarea">
                <input type="checkbox" name="icp"> 提示: 仅HTTP/HTTPS转发有效
            </td>
        </tr>

        <tr>
            <td width="20%" class="fieldlabel">可用协议</td>
            <td class="fieldarea">
                <?php foreach ($protocols as $protocol => $value) { ?>
                    <input type="checkbox" name="protocol[<?php echo $protocol; ?>]"><?php echo $value; ?>
                    <br>
                <?php } ?>
            </td>
        </tr>

        <tr>
            <td class="fieldlabel">保留的目标端口</td>
            <td class="fieldarea"><textarea name="retain_remoteport" class="form-control input-inline input-400" placeholder="1-1024&#10;65535"></textarea></td>
        </tr>

        <tr>
            <td class="fieldlabel">保留的监听端口</td>
            <td class="fieldarea"><textarea name="retain_port" class="form-control input-inline input-400" placeholder="1-1024&#10;65535"></textarea></td>
        </tr>

        <tr>
            <td class="fieldlabel">速率控制</td>
            <td class="fieldarea"><input type="number" name="speed_times" min="0" step="0.01" class="form-control input-inline input-400" placeholder="1" required>倍</td>
        </tr>

        <tr>
            <td class="fieldlabel">流量消耗</td>
            <td class="fieldarea"><input type="number" name="traffic_times" min="0" step="0.01" class="form-control input-inline input-400" placeholder="1" required>倍</td>
        </tr>

        <tr>
            <td class="fieldlabel">更新周期</td>
            <td class="fieldarea"><input type="number" name="cron" min="60" class="form-control input-inline input-400" placeholder="300" required>秒</td>
        </tr>

        <tr>
            <td class="fieldlabel">描述</td>
            <td class="fieldarea"><input type="text" name="description" class="form-control input-inline input-400"></td>
        </tr>
    </tbody>
</table>

<div align="center">
    <button type="submit" class="btn btn-success text-center"><i class="md md-assignment-turned-in"></i>提交</button>
    <button type="button" class="btn btn-default text-center" onClick='window.location.href="?module=PortForwardGo&page=<?php echo $_REQUEST['page']; ?>"'><i class="md md-assignment-turned-in"></i>取消</button>
</div>

<script type="text/javascript">
    $(function() {
        $("#plan").fSelect();
    });
</script>