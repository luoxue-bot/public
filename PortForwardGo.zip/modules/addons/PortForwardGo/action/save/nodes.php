<?php

use Illuminate\Database\Capsule\Manager as Capsule;

$protocol_list = PortForwardGo_AllProtocol();
foreach ($protocol_list as $protocol => $value) {
    $protocols[$protocol] = false;
}

foreach ($protocols as $name => $value) {
    $protocols[$name] = false;
    if ($_REQUEST['protocol'][$name] == 'on') {
        $protocols[$name] = true;
    }
}

$api = $_REQUEST['api'] == 'on' ? true : false;
$icp = $_REQUEST['icp'] == 'on' ? true : false;

$is_domain = preg_match("/^(?!:\/\/)(?!.{256,})(([a-z0-9][a-z0-9_-]*?)|([a-z0-9][a-z0-9_-]*?\.)+?[a-z]{2,6}?)$/i", $_REQUEST['addr']);
if (!filter_var(trim($_REQUEST['addr']), FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_IPV6)) {
    if (!$is_domain) {
        PortForwardGo_PrintText(false, "无效的节点地址!");
        return;
    }
}

if ($_REQUEST['cron'] < 60) {
    PortForwardGo_PrintText(false, "更新速度过快!");
    return;
}

if ($_REQUEST['speed_times'] <= 0) {
    PortForwardGo_PrintText(false, "无效的速率控制值!");
    return;
}


if ($_REQUEST['traffic_times'] < 0) {
    PortForwardGo_PrintText(false, "无效的流量消耗值!");
    return;
}

if ($_REQUEST['apiport'] < 1 || $_REQUEST['apiport'] > 65535) {
    PortForwardGo_PrintText(false, "无效的API端口!");
    return;
}

if ($_REQUEST['http_port'] < 1 || $_REQUEST['http_port'] > 65535) {
    PortForwardGo_PrintText(false, "无效的HTTP端口!");
    return;
}


if ($_REQUEST['https_port'] < 0 || $_REQUEST['https_port'] > 65535) {
    PortForwardGo_PrintText(false, "无效的HTTPS端口!");
    return;
}

if ($_REQUEST['http_port_2'] < 1 || $_REQUEST['http_port_2'] > 65535) {
    PortForwardGo_PrintText(false, "无效的HTTP端口2!");
    return;
}

if ($_REQUEST['https_port_2'] < 0 || $_REQUEST['https_port_2'] > 65535) {
    PortForwardGo_PrintText(false, "无效的HTTPS端口2!");
    return;
}


if ($_REQUEST['rc_tcp_port'] < 0 || $_REQUEST['rc_tcp_port'] > 65535) {
    PortForwardGo_PrintText(false, "无效的内网穿透 TCP连接端口!");
    return;
}


if ($_REQUEST['rc_kcp_port'] < 0 || $_REQUEST['rc_kcp_port'] > 65535) {
    PortForwardGo_PrintText(false, "无效的内网穿透 KCP(UDP)连接端口!");
    return;
}

if (!is_array($_REQUEST['plan'])) {
    $_REQUEST['plan'] = [];
}

$plans = Capsule::table("mod_PortForwardGo_Plans")->get();

if (isset($_REQUEST['id'])) {
    foreach ($plans as $plan) {
        $select_nodes = explode("|", $plan->node);
        if (in_array($plan->id, $_REQUEST['plan']) && !in_array($_REQUEST['id'], $select_nodes)) {
            array_push($select_nodes, $_REQUEST['id']);
            Capsule::table('mod_PortForwardGo_Plans')->where('id', $plan->id)->update(['node' => implode("|", $select_nodes)]);
        } else if (!in_array($plan->id, $_REQUEST['plan']) && in_array($_REQUEST['id'], $select_nodes)) {
            $select_nodes = array_diff($select_nodes, [$_REQUEST['id']]);
            Capsule::table('mod_PortForwardGo_Plans')->where('id', $plan->id)->update(['node' => implode("|", $select_nodes)]);
        }
    }

    $sql = Capsule::table('mod_PortForwardGo_Node')->where('id', $_REQUEST['id']);
    if ($sql->exists()) {
        $sql->update([
            'name' => $_REQUEST['name'],
            'addr' => $_REQUEST['addr'],
            'api' => $api,
            'apiport' => $_REQUEST['apiport'],
            'rc_tcp_port' => $_REQUEST['rc_tcp_port'],
            'rc_kcp_port' => $_REQUEST['rc_kcp_port'],
            'protocol' => json_encode($protocols),
            'retain_remoteport' => $_REQUEST['retain_remoteport'],
            'retain_port' => $_REQUEST['retain_port'],
            'speed_times' => $_REQUEST['speed_times'],
            'traffic_times' => $_REQUEST['traffic_times'],
            'cron' => $_REQUEST['cron'],
            'http_port' => $_REQUEST['http_port'],
            'http_port_2' => $_REQUEST['http_port_2'],
            'https_port' => $_REQUEST['https_port'],
            'https_port_2' => $_REQUEST['https_port_2'],
            'icp' => $icp,
            'description' => $_REQUEST['description'],
        ]);
        PortForwardGo_PrintText(true, '保存成功!');
    } else {
        PortForwardGo_PrintText(false, "节点不存在!");
    }
} else {
    $nodeid = Capsule::table('mod_PortForwardGo_Node')->insertGetId([
        'name' => $_REQUEST['name'],
        'addr' => $_REQUEST['addr'],
        'api' => $api,
        'apiport' => $_REQUEST['apiport'],
        'rc_tcp_port' => $_REQUEST['rc_tcp_port'],
        'rc_kcp_port' => $_REQUEST['rc_kcp_port'],
        'protocol' => json_encode($protocols),
        'retain_remoteport' => $_REQUEST['retain_remoteport'],
        'retain_port' => $_REQUEST['retain_port'],
        'speed_times' => $_REQUEST['speed_times'],
        'traffic_times' => $_REQUEST['traffic_times'],
        'cron' => $_REQUEST['cron'],
        'http_port' => $_REQUEST['http_port'],
        'http_port_2' => $_REQUEST['http_port_2'],
        'https_port' => $_REQUEST['https_port'],
        'https_port_2' => $_REQUEST['https_port_2'],
        'icp' => $icp,
        'description' => $_REQUEST['description'],
    ]);

    foreach ($plans as $plan) {
        if (in_array($plan->id, $_REQUEST['plan'])) {
            $select_nodes = explode("|", $plan->node);
            array_push($select_nodes, $nodeid);
            Capsule::table('mod_PortForwardGo_Plans')->where('id', $plan->id)->update(['node' => implode("|", $select_nodes)]);
        }
    }
    PortForwardGo_PrintText(true, '保存成功! 节点ID: ' . $nodeid);
}
