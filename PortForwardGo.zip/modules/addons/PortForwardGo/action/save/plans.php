<?php

use Illuminate\Database\Capsule\Manager as Capsule;

if (isset($_REQUEST['node'])) {
    $nodes = implode("|", $_REQUEST['node']);
} else {
    $nodes = '';
}

$protocols = PortForwardGo_AllProtocol();

foreach ($protocols as $name => $value) {
    $protocols[$name] = false;
    if ($_REQUEST['protocol'][$name] == 'on') {
        $protocols[$name] = true;
    }
}

if ($_REQUEST['speed'] < 0) {
    PortForwardGo_PrintText(false, '无效的速率限制值');
    return;
}

if ($_REQUEST['conn'] < 0) {
    PortForwardGo_PrintText(false, '无效的连接数限制值');
    return;
}

if ($_REQUEST['rules'] < 1) {
    PortForwardGo_PrintText(false, '无效的规则数量值');
    return;
}

if ($_REQUEST['traffic'] < 0) {
    PortForwardGo_PrintText(false, '无效的流量值');
    return;
}

if (isset($_REQUEST['id'])) {

    $sql = Capsule::table('mod_PortForwardGo_Plans')->where('id', $_REQUEST['id']);
    if ($sql->exists()) {
        $sql->update([
            'name' => $_REQUEST['name'],
            'node' => $nodes,
            'protocol' => json_encode($protocols),
            'rules' => $_REQUEST['rules'],
            'traffic' => $_REQUEST['traffic'] * 1073741824,
            'speed' => $_REQUEST['speed'],
            'conn' => $_REQUEST['conn'],
        ]);
        PortForwardGo_PrintText(true, '保存成功!');
    } else {
        PortForwardGo_PrintText(false, '套餐不存在!');
    }
} else {

    Capsule::table('mod_PortForwardGo_Plans')->insert([
        'name' => $_REQUEST['name'],
        'node' => $nodes,
        'protocol' => json_encode($protocols),
        'rules' => $_REQUEST['rules'],
        'traffic' => $_REQUEST['traffic'] * 1073741824,
        'speed' => $_REQUEST['speed'],
        'conn' => $_REQUEST['conn'],
    ]);
    PortForwardGo_PrintText(true, '保存成功!');
}
