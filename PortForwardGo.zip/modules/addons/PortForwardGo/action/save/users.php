<?php
use Illuminate\Database\Capsule\Manager as Capsule;

if($_REQUEST['speed'] < 0){
    PortForwardGo_PrintText(false,'无效的速率限制值');
    return;
}

if($_REQUEST['max_rules'] < 1){
    PortForwardGo_PrintText(false,'无效的规则数量值');
    return;
}

if($_REQUEST['traffic'] < 1){
    PortForwardGo_PrintText(false,'无效的总流量值');
    return;
}

if($_REQUEST['traffic_used'] < 0){
    PortForwardGo_PrintText(false,'无效的已用流量值');
    return;
}

if($_REQUEST['max_conn'] < 0){
    PortForwardGo_PrintText(false,'无效的连接数限制值');
    return;
}

if(isset($_REQUEST['id'])){
    
    $sql = Capsule::table('mod_PortForwardGo_Users')->where('id',$_REQUEST['id']);
    if($sql->exists()){
    $sql->update([
        'pid' => $_REQUEST['pid'],
        'max_rules' => $_REQUEST['max_rules'],
        'speed' => $_REQUEST['speed'],
        'max_conn' => $_REQUEST['max_conn'],
        'traffic' => $_REQUEST['traffic'] * 1073741824,
        'traffic_used' => $_REQUEST['traffic_used'] * 1073741824,
        ]);
        PortForwardGo_PrintText(true,'保存成功!');
    }else{
        PortForwardGo_PrintText(false,'订单不存在!');
    }
}else{
PortForwardGo_PrintText(true,'请求参数丢失');
}