<?php

use Illuminate\Database\Capsule\Manager as Capsule;

if (isset($_REQUEST['id'])) {
    $sql = Capsule::table('mod_PortForwardGo_Rules')->where('id', $_REQUEST['id'])->where('status', '!=', 'Deleted');
    if ($sql->exists()) {
        $info = $sql->first();
        $is_domain = preg_match("/^(?!:\/\/)(?!.{256,})(([a-z0-9][a-z0-9_-]*?)|([a-z0-9][a-z0-9_-]*?\.)+?[a-z]{2,15}?)$/i", $_REQUEST['remoteip']);
        if (!filter_var(trim($_REQUEST['remoteip']), FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_IPV6)) {
            if (!$is_domain) {
                PortForwardGo_PrintText(false, "连接地址不合法");
                return;
            }
        }

        if ($_REQUEST["remoteport"] < 1 || $_REQUEST["remoteport"] > 65535) {
            PortForwardGo_PrintText(false, "连接端口不合法");
            return;
        }

        $sql->update([
            'remoteip' => $_REQUEST['remoteip'],
            'remoteport' => $_REQUEST['remoteport'],
            'proxyprotocolversion' => $_REQUEST['proxyprotocolversion'],
            'rc' => $_REQUEST['rc'] == "1" ? true : false,
            'msg' => $_REQUEST['msg'],
            'status' => $_REQUEST['status'],
        ]);

        if (!(bool)$info->rc && $_REQUEST['rc'] == "1") {
            $sql = Capsule::table("mod_PortForwardGo_RClient_Changes")->where("rule_id", $info->id)->where('status', 'Deleted');
            if ($sql->exists()) {
                $sql->delete();
            } else {
                Capsule::table("mod_PortForwardGo_RClient_Changes")->insert(['sid' => $info->sid, 'node' => $info->node, 'rule_id' => $info->id, 'status' => 'Created']);
            }
        }

        if ((bool)$info->rc && $_REQUEST['rc'] == "0") {
            $sql = Capsule::table("mod_PortForwardGo_RClient_Changes")->where("rule_id", $info->id)->where('status', 'Created');
            if ($sql->exists()) {
                $sql->delete();
            } else {
                Capsule::table("mod_PortForwardGo_RClient_Changes")->insert(['sid' => $info->sid, 'node' => $info->node, 'rule_id' => $info->id, 'status' => 'Deleted']);
            }
        }


        PortForwardGo_APICall($_REQUEST['id']);
        PortForwardGo_PrintText(true, '保存成功!');
    } else {
        PortForwardGo_PrintText(false, '规则不存在!');
    }
} else {
    PortForwardGo_PrintText(true, '请求参数丢失');
}
