<?php

use Illuminate\Database\Capsule\Manager as Capsule;

$sql = Capsule::table('mod_PortForwardGo_Users')->where('id', $_REQUEST['id']);
$plans = Capsule::table('mod_PortForwardGo_Plans')->get();
if (!$sql->exists()) {
    PortForwardGo_PrintText(false, "订单不存在!");
    return;
}
$info = $sql->first();
$protocols = PortForwardGo_AllProtocol();
?>
<h1>编辑</h1>
<input type="hidden" name="a" value="save">
<input type="hidden" name="page" value="<?php echo $_REQUEST['page']; ?>">
<input type="hidden" name="id" value="<?php echo $_REQUEST['id']; ?>">
<table class="form" width="100%" border="0" cellspacing="2" cellpadding="3">
    <tbody>

        <tr>
            <td class="fieldlabel">套餐</td>
            <td class="fieldarea">
                <select id="pid" name="pid" class="form-control select-inline">
                    <?php foreach ($plans as $plan) { ?>
                        <option value="<?php echo $plan->id; ?>" <?php echo $info->pid == $plan->id ? "selected" : ""; ?>><?php echo $plan->name; ?></option>
                    <?php } ?>
                </select>
            </td>
        </tr>

        <tr>
            <td class="fieldlabel">规则数量</td>
            <td class="fieldarea"><input type="text" min="1" value="<?php echo $info->max_rules; ?>" name="max_rules" class="form-control input-inline input-400" required>条</td>
        </tr>

        <tr>
            <td class="fieldlabel">总流量</td>
            <td class="fieldarea"><input type="number" min="1" value="<?php echo ceil($info->traffic / 1073741824); ?>" name="traffic" class="form-control input-inline input-400" required>GB</td>
        </tr>

        <tr>
            <td class="fieldlabel">已用流量</td>
            <td class="fieldarea"><input type="number" min="0" value="<?php echo ceil($info->traffic_used / 1073741824); ?>" name="traffic_used" class="form-control input-inline input-400" required>GB</td>
        </tr>

        <tr>
            <td class="fieldlabel">速率</td>
            <td class="fieldarea"><input type="number" min="0" value="<?php echo $info->speed; ?>" name="speed" class="form-control input-inline input-400" required>Mbps（不限制为0）</td>
        </tr>

        <tr>
            <td class="fieldlabel">连接数</td>
            <td class="fieldarea"><input type="number" min="0" value="<?php echo $info->max_conn; ?>" name="max_conn" class="form-control input-inline input-400" required>个（不限制为0）</td>
        </tr>
    </tbody>
</table>

<div align="center">
    <button type="submit" class="btn btn-success text-center"><i class="md md-assignment-turned-in"></i>提交</button>
    <button type="button" class="btn btn-default text-center" onClick='window.location.href="?module=PortForwardGo&page=<?php echo $_REQUEST['page']; ?>"'><i class="md md-assignment-turned-in"></i>取消</button>
</div>