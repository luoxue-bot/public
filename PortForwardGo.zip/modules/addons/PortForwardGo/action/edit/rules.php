<?php

use Illuminate\Database\Capsule\Manager as Capsule;

$sql = Capsule::table('mod_PortForwardGo_Rules')->where('id', $_REQUEST['id'])->where('status', '!=', 'Deleted');
if (!$sql->exists()) {
    PortForwardGo_PrintText(false, "规则不存在!");
    return;
}
$info = $sql->first();
$node = Capsule::table('mod_PortForwardGo_Node')->where('id', $info->node)->first();
$protocols = PortForwardGo_AllProtocol();
$proxyprotocolversion = PortForwardGo_AllProxyProtocolVersion();
$status = PortForwardGo_StatusArray();
?>
<h1>编辑</h1>
<input type="hidden" name="a" value="save">
<input type="hidden" name="page" value="<?php echo $_REQUEST['page']; ?>">
<input type="hidden" name="id" value="<?php echo $_REQUEST['id']; ?>">
<table class="form" width="100%" border="0" cellspacing="2" cellpadding="3">
    <tbody>
        <tr>
            <td class="fieldlabel">协议</td>
            <td class="fieldarea"><input type="text" value="<?php echo $protocols[$info->protocol]; ?>" name="name" class="form-control input-inline input-400" disabled></td>
        </tr>

        <tr>
            <td class="fieldlabel">代理协议<i class="glyphicon glyphicon-question-sign" OnClick="ProxyProtocolAbout()"></i></td>
            <td class="fieldarea">
                <select id="proxyprotocolversion" name="proxyprotocolversion" class="form-control select-inline">
                    <?php foreach ($proxyprotocolversion as $value => $display) { ?>
                        <option value="<?php echo $value; ?>" <?php echo $info->proxyprotocolversion == $value ? "selected" : ""; ?>><?php echo $display; ?></option>
                    <?php } ?>
                </select>
            </td>
        </tr>

        <tr>
            <td class="fieldlabel">内网穿透</td>
            <td class="fieldarea">
                <select id="rc" name="rc" class="form-control select-inline">
                        <option value="0" <?php echo (bool)$info->rc ? "" : "selected"; ?>>否</option>
                        <option value="1" <?php echo (bool)$info->rc ? "selected" : ""; ?>>是</option>
                </select>
            </td>
        </tr>

        <tr>
            <td class="fieldlabel">目标地址</td>
            <td class="fieldarea"><input type="text" value="<?php echo $info->remoteip; ?>" name="remoteip" class="form-control input-inline input-400" onkeyup="this.value=this.value.toLowerCase()" required>域名或IP</td>
        </tr>

        <tr>
            <td class="fieldlabel">目标端口</td>
            <td class="fieldarea"><input type="number" value="<?php echo $info->remoteport; ?>" min="1" max="65535" name="remoteport" class="form-control input-inline input-400" required></td>
        </tr>

        <tr>
            <td class="fieldlabel">连接端口/域名</td>
            <td class="fieldarea"><input type="text" value="<?php echo $info->port; ?>" name="apiport" class="form-control input-inline input-400" onkeyup="this.value=this.value.toLowerCase()" disabled></td>
        </tr>

        <tr>
            <td class="fieldlabel">备注</td>
            <td class="fieldarea"><input type="text" maxlength="25" value="<?php echo $info->msg; ?>" name="msg" class="form-control input-inline input-400"></td>
        </tr>

        <tr>
            <td class="fieldlabel">节点</td>
            <td class="fieldarea"><input type="text" value="<?php echo $node->name; ?>" name="node" class="form-control input-inline input-400" disabled></td>
        </tr>

        <tr>
            <td class="fieldlabel">状态</td>
            <td class="fieldarea">
                <select id="status" name="status" class="form-control select-inline" <?php echo in_array($info->status, ["Created", "Deleted", "Error"]) ? "disabled" : ""; ?>>
                    <?php foreach ($status as $name => $view) { ?>
                        <option value="<?php echo $name; ?>" <?php echo in_array($name, ['Created', 'Deleted', 'Error']) ? "disabled" : ""; ?>><?php echo $view; ?></option>
                        <?php } ?>
                </select>
            </td>
        </tr>

    </tbody>
</table>

<div align="center">
    <button type="submit" class="btn btn-success text-center"><i class="md md-assignment-turned-in"></i>提交</button>
    <button type="button" class="btn btn-default text-center" onClick='window.location.href="?module=PortForwardGo&page=<?php echo $_REQUEST['page']; ?>"'><i class="md md-assignment-turned-in"></i>取消</button>
</div>