<?php
use Illuminate\Database\Capsule\Manager as Capsule;
if(isset($_REQUEST['id'])){
    if(Capsule::table('mod_PortForwardGo_Plans')->where('id',$_REQUEST['id'])->exists()){
    $sql = Capsule::table('mod_PortForwardGo_Users')->where('pid',$_REQUEST['id'])->get();
    $users = [];
    foreach($sql as $user){
        $users[] = $user->sid;
    }
    Capsule::table('mod_PortForwardGo_Users')->whereIn('sid',$users)->delete();
    Capsule::table('tblhosting')->whereIn('id',$users)->delete();
    Capsule::table('mod_PortForwardGo_Rules')->whereIn('sid',$users)->update(['status' => 'Deleted']);
    PortForwardGo_PrintText(true,'套餐订单清理成功');
    }else{
        PortForwardGo_PrintText(false,'套餐不存在');
    }
}else{
    PortForwardGo_PrintText(false,'请求参数缺失');
}