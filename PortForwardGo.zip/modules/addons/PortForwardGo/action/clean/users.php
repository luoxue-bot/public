<?php
use Illuminate\Database\Capsule\Manager as Capsule;
if(isset($_REQUEST['id'])){
    if(Capsule::table('mod_PortForwardGo_Users')->where('sid',$_REQUEST['sid'])->exists()){
      Capsule::table('mod_PortForwardGo_Rules')->where('sid',$_REQUEST['sid'])->update(['status' => 'Deleted']);
      
        PortForwardGo_PrintText(true,'用户规则清理成功');
    }else{
        PortForwardGo_PrintText(false,'用户不存在');
    }
}else{
    PortForwardGo_PrintText(false,'请求参数缺失');
}