<?php
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}
require_once __DIR__ . '/func.php';

use Illuminate\Database\Capsule\Manager as Capsule;

add_hook('DailyCronJob', 1, function ($vars) {
    Capsule::table('mod_PortForwardGo_Info')->where('name', 'today_traffic')->update(['value' => '0']);
    if (date('d') == '01') {
        Capsule::table('mod_PortForwardGo_Info')->where('name', 'month_traffic')->update(['value' => '0']);
    }
    $services = Capsule::table('mod_PortForwardGo_Services')->get();
    $timestarp = strtotime(date("Y-m-d"));
    foreach ($services as $service) {
        if (strtotime($service->restdate) <= $timestarp) {
            Capsule::table('mod_PortForwardGo_Services')->where('id', $service->id)->update(['restdate' => date('Y-m-d', strtotime('+1 month'))]);
            Capsule::table('mod_PortForwardGo_Users')->where('sid', $service->sid)->update(['traffic_used' => 0]);
            Capsule::table("mod_PortForwardGo_Rules")->where('sid', $service->sid)->where('status', 'Exhaust')->update(['status' => 'Active']);
        }
    }
});

add_hook('AfterCronJob', 1, function ($vars) {
    /* 刷新连接数
    $plans = Capsule::table("mod_PortForwardGo_Plans")->get();
    foreach ($plans as $plan) {
        Capsule::table("mod_PortForwardGo_Users")->where("pid", $plan->id)->update(['max_conn' => $plan->conn]);
    }
    */
    PortForwardGo_UpdateStatus();
});
