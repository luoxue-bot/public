<?php
set_time_limit(0);
require_once __DIR__ . "/../../../init.php";
require_once __DIR__ . "/func.php";
require_once __DIR__ . "/version.php";

use Illuminate\Database\Capsule\Manager as Capsule;

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    exit('Unsupport Method');
}

$config = PortForwardGo_GetConfigModule();
$postdata = json_decode(file_get_contents("php://input"), true);

if (!is_array($postdata)) {
    header("HTTP/1.1 503 Service Unavailable");
    exit('Wrong Data');
}

if ($postdata['Token'] != md5($config['key'])) {
    header("HTTP/1.1 503 Service Unavailable");
    exit('Wrong Token.');
}

if ($postdata['Action'] == 'Save') {
    $sql = Capsule::table('mod_PortForwardGo_Node')->where('id', $postdata['NodeID']);

    if (!$sql->exists()) {
        header("HTTP/1.1 503 Service Unavailable");
        exit('Wrong NodeID');
    }

    $sql->update(['updated' => date('Y-m-d H:i:s')]);

    $traffic_times = $sql->first()->traffic_times;

    if (count($postdata['Bandwidth']) != 0) {
        if ($traffic_times != 0) {
            $users = Capsule::table("mod_PortForwardGo_Users")->get();
            foreach ($users as $user) {
                if ($postdata['Bandwidth'][$user->sid] != 0) {
                    $used = $user->traffic_used + ceil($postdata['Bandwidth'][$user->sid] * $traffic_times);
                    Capsule::table("mod_PortForwardGo_Users")->where('id', $user->id)->update(['traffic_used' => $used]);
                }
            }
        }

        foreach ($postdata['Bandwidth'] as $value) {
            $all_used += $value;
        }

        if ($all_used != 0) {
            Capsule::table('mod_PortForwardGo_Info')->where('name', 'today_traffic')->update(['value' => Capsule::table('mod_PortForwardGo_Info')->where('name', 'today_traffic')->first()->value + $all_used]);
            Capsule::table('mod_PortForwardGo_Info')->where('name', 'month_traffic')->update(['value' => Capsule::table('mod_PortForwardGo_Info')->where('name', 'month_traffic')->first()->value + $all_used]);
        }
    }
    Capsule::table("mod_PortForwardGo_Rules")->where('node', $postdata['NodeID'])->where('status', "Active")->update(['status' => 'Created']);
    header('HTTP/1.1 204 No Content');
    exit;
}

if ($postdata['Version'] != $version) {
    header("HTTP/1.1 503 Service Unavailable");
    exit('The API does not support this version of the client, please update your api or client.');
}

if ($postdata['Action'] == 'GetConfig') {
    $sql = Capsule::table('mod_PortForwardGo_Node')->where('id', $postdata['NodeID']);

    if (!$sql->exists()) {
        header("HTTP/1.1 503 Service Unavailable");
        exit('Wrong NodeID');
    }

    $data = $sql->first();
    $traffic_times = $data->traffic_times;
    $speed_times = $data->speed_times;

    $conf = array(
        'Cron' => $data->cron,
        'API' => (bool)$data->api,
        'APIPort' => (string)$data->apiport,
        'RC_TCP_Port' => (string)$data->rc_tcp_port,
        'RC_KCP_Port' => (string)$data->rc_kcp_port,
    );

    $protocols = json_decode($data->protocol, true);
    $conf['Listen']['Http']['Enable'] = $protocols['http'];
    $conf['Listen']['Https']['Enable'] = $protocols['https'];
    $conf['Listen']['Http']['Port'] = (string)$data->http_port;
    $conf['Listen']['Https']['Port'] = (string)$data->https_port;

    if ($protocols['http'] && $data->http_port != $data->http_port_2 && $data->http_port_2 != 0) {
        $conf['Listen']['Http_2']['Enable'] = true;
        $conf['Listen']['Http_2']['Port'] = (string)$data->http_port_2;
    }

    if ($protocols['https'] && $data->https_port != $data->https_port_2 && $data->https_port_2 != 0) {
        $conf['Listen']['Https_2']['Enable'] = true;
        $conf['Listen']['Https_2']['Port'] = (string)$data->https_port_2;
    }

    exit(json_encode($conf));
}

if ($postdata['Action'] == 'GetRules') {
    $sql = Capsule::table('mod_PortForwardGo_Node')->where('id', $postdata['NodeID']);

    if (!$sql->exists()) {
        header("HTTP/1.1 503 Service Unavailable");
        exit('Wrong NodeID');
    }

    $data = $sql->first();
    $sql->update(['updated' => date('Y-m-d H:i:s')]);

    if (!Capsule::table("mod_PortForwardGo_Rules")->where('node', $postdata['NodeID'])->exists()) {
        header('HTTP/1.1 204 No Content');
        exit;
    }

    $traffic_times = $data->traffic_times;
    $speed_times = $data->speed_times;

    $conf = [];
    $protocols = json_decode($data->protocol, true);

    Capsule::table("mod_PortForwardGo_Rules")->where('node', $postdata['NodeID'])->whereIn('status', ["Created", "Error"])->update(['status' => 'Active']);
    Capsule::table("mod_PortForwardGo_Rules")->where('node', $postdata['NodeID'])->where('status', "Deleted")->delete();

    $sql = Capsule::table("mod_PortForwardGo_Users")->get();
    foreach ($sql as $user) {
        $conn[$user->sid] = $user->max_conn;
        $speed[$user->sid] = $user->speed;
        if ($user->traffic > $user->traffic_used) {
            if ($traffic_times == 0) {
                $quota[$user->sid] = 9223372036854775807;
            } else {
                $quota[$user->sid] = ceil(($user->traffic - $user->traffic_used) / $traffic_times);
            }
        } else {
            $quota[$user->sid] = 0;
        }
    }

    $rules = Capsule::table("mod_PortForwardGo_Rules")->where('node', $postdata['NodeID'])->get();
    foreach ($rules as $rule) {
        if (!$protocols[$rule->protocol]) {
            $errors_id[] = $rule->id;
            continue;
        }

        $conf[(string)$rule->id]['Status'] = $rule->status;
        $conf[(string)$rule->id]['UID'] = (string)$rule->sid;
        $conf[(string)$rule->id]['Protocol'] = $rule->protocol;
        $conf[(string)$rule->id]['Listen'] = $rule->port;
        $conf[(string)$rule->id]['RemoteHost'] = $rule->remoteip;
        $conf[(string)$rule->id]['RemotePort'] = (int)$rule->remoteport;

        $conf[(string)$rule->id]['ProxyProtocolVersion'] = $rule->proxyprotocolversion;
        $conf[(string)$rule->id]['RC'] = (bool)$rule->rc;
        $conf[(string)$rule->id]['Speed'] = ceil($speed[$rule->sid] * $speed_times);
        $conf[(string)$rule->id]['Quota'] = $quota[$rule->sid];
        $conf[(string)$rule->id]['MaxConn'] = $conn[$rule->sid];
    }
    if (isset($errors_id)) {
        Capsule::table('mod_PortForwardGo_Rules')->whereIn('id', $errors_id)->update(['status' => 'Error']);
    }

    exit(json_encode($conf));
}

if ($postdata['Action'] == 'UpdateRules') {
    $sql = Capsule::table('mod_PortForwardGo_Node')->where('id', $postdata['NodeID']);

    if (!$sql->exists()) {
        header("HTTP/1.1 503 Service Unavailable");
        exit('Wrong NodeID');
    }

    $data = $sql->first();
    $traffic_times = $data->traffic_times;
    $speed_times = $data->speed_times;

    $conf = [];
    $protocols = json_decode($data->protocol, true);

    $sql->update(['updated' => date('Y-m-d H:i:s')]);

    if (count($postdata['Bandwidth']) != 0) {
        if ($traffic_times != 0) {
            $users = Capsule::table("mod_PortForwardGo_Users")->get();
            foreach ($users as $user) {
                if ($postdata['Bandwidth'][$user->sid] != 0) {
                    $used = $user->traffic_used + ceil($postdata['Bandwidth'][$user->sid] * $traffic_times);
                    Capsule::table("mod_PortForwardGo_Users")->where('id', $user->id)->update(['traffic_used' => $used]);
                }
            }
        }

        foreach ($postdata['Bandwidth'] as $value) {
            $all_used += $value;
        }

        if ($all_used != 0) {
            Capsule::table('mod_PortForwardGo_Info')->where('name', 'today_traffic')->update(['value' => Capsule::table('mod_PortForwardGo_Info')->where('name', 'today_traffic')->first()->value + $all_used]);
            Capsule::table('mod_PortForwardGo_Info')->where('name', 'month_traffic')->update(['value' => Capsule::table('mod_PortForwardGo_Info')->where('name', 'month_traffic')->first()->value + $all_used]);
        }
    }

    if (!Capsule::table("mod_PortForwardGo_Rules")->where('node', $postdata['NodeID'])->exists()) {
        header('HTTP/1.1 204 No Content');
        exit;
    }

    $sql = Capsule::table("mod_PortForwardGo_Users")->get();
    foreach ($sql as $user) {
        $conn[$user->sid] = $user->max_conn;
        $speed[$user->sid] = $user->speed;
        if ($user->traffic > $user->traffic_used) {
            if ($traffic_times == 0) {
                $quota[$user->sid] = 9223372036854775807;
            } else {
                $quota[$user->sid] = ceil(($user->traffic - $user->traffic_used) / $traffic_times);
            }
        } else {
            $quota[$user->sid] = 0;
        }
    }

    $rules = Capsule::table("mod_PortForwardGo_Rules")->where('node', $postdata['NodeID'])->get();
    foreach ($rules as $rule) {
        if (!$protocols[$rule->protocol]) {
            $errors_id[] = $rule->id;
            $conf[(string)$rule->id]['Status'] = 'Error';
        } else {
            $conf[(string)$rule->id]['Status'] = $rule->status;
        }

        $conf[(string)$rule->id]['UID'] = (string)$rule->sid;
        $conf[(string)$rule->id]['Protocol'] = $rule->protocol;
        $conf[(string)$rule->id]['Listen'] = $rule->port;
        $conf[(string)$rule->id]['RemoteHost'] = $rule->remoteip;
        $conf[(string)$rule->id]['RemotePort'] = (int)$rule->remoteport;

        $conf[(string)$rule->id]['ProxyProtocolVersion'] = $rule->proxyprotocolversion;
        $conf[(string)$rule->id]['RC'] = (bool)$rule->rc;
        $conf[(string)$rule->id]['Speed'] = ceil($speed[$rule->sid] * $speed_times);
        $conf[(string)$rule->id]['Quota'] = $quota[$rule->sid];
        $conf[(string)$rule->id]['MaxConn'] = $conn[$rule->sid];
    }

    if (isset($errors_id)) {
        Capsule::table('mod_PortForwardGo_Rules')->whereIn('id', $errors_id)->update(['status' => 'Error']);
    }

    Capsule::table("mod_PortForwardGo_Rules")->where('node', $postdata['NodeID'])->where('status', "Created")->update(['status' => 'Active']);
    Capsule::table("mod_PortForwardGo_Rules")->where('node', $postdata['NodeID'])->where('status', "Deleted")->delete();

    exit(json_encode($conf));
}

if ($postdata['Action'] == 'Error') {
    $sql = Capsule::table('mod_PortForwardGo_Node')->where('id', $postdata['NodeID']);

    if (!$sql->exists()) {
        header("HTTP/1.1 503 Service Unavailable");
        exit('Wrong NodeID');
    }

    Capsule::table('mod_PortForwardGo_Rules')->where('id', $postdata['RuleID'])->update(['status' => 'Error']);

    header('HTTP/1.1 204 No Content');
    exit;
}
