<?php

use Illuminate\Database\Capsule\Manager as Capsule;

if (!isset($_REQUEST['pages']) || empty($_REQUEST['pages'])) {
	$_REQUEST['pages'] = 1;
}
if (isset($_REQUEST['sid'])) {
	$array = Capsule::table('mod_PortForwardGo_Users')->where('sid', $_REQUEST['sid'])->orderBy('id', 'desc')->offset(($_REQUEST['pages'] - 1) * 50)->limit(50)->get();
	$count = ceil(Capsule::table('mod_PortForwardGo_Users')->where('sid', $_REQUEST['sid'])->count() / 50);
} else {
	$array = Capsule::table('mod_PortForwardGo_Users')->orderBy('id', 'desc')->offset(($_REQUEST['pages'] - 1) * 50)->limit(50)->get();
	$count = ceil(Capsule::table('mod_PortForwardGo_Users')->count() / 50);
}
?>
<div class="row">
	<div class="col-md-12">
	</div>
	<div class="col-md-12">
		<div class="block block-rounded block-bordered">
			<div class="block-content" style="padding:0">
				<table id="<?php echo $_REQUEST['page']; ?>" class="table table-hover js-dataTable-full" style="margin-bottom:0">
					<colgroup>
						<col width="3%">
						<col width="3%">
						<col width="3%">
						<col width="3%">
						<col width="5%">
						<col width="10%">
						<col width="10%">
						<col width="10%">
					</colgroup>
					<thead>
						<tr>
							<th>ID</th>
							<th>服务ID</th>
							<th>套餐</th>
							<th>带宽</th>
							<th>转发规则</th>
							<th>总流量</th>
							<th>已用流量</th>
							<th>操作</th>
						</tr>
					</thead>
					<tbody>
						<?php if (count($array) != 0) { ?>
							<?php foreach ($array as $value) { ?>
								<tr id="<?php echo $_REQUEST['page']; ?>_<?php echo $value->id; ?>">
									<td><?php echo $value->id; ?></td>
									<td><a href="clientsservices.php?id=<?php echo $value->sid; ?>"><?php echo $value->sid; ?></a></td>
									<td><a href="?module=PortForwardGo&page=plans&id=<?php echo $value->pid; ?>"><?php echo Capsule::table('mod_PortForwardGo_Plans')->where('id', $value->pid)->first()->name; ?></a></td>
									<td><?php echo $value->speed == 0 ? '不限制' : $value->speed . ' Mbps'; ?></td>
									<td><a href="?module=PortForwardGo&page=rules&id=<?php echo $value->sid; ?>"><?php echo Capsule::table('mod_PortForwardGo_Rules')->where('sid', $value->sid)->where('status', '!=', 'Deleted')->count(); ?>/<?php echo $value->max_rules; ?></a></td>
									<td><?php echo ceil($value->traffic / 1073741824); ?> GB</td>
									<td><?php echo ceil($value->traffic_used / 1073741824); ?> GB</td>
									<td>
										<a class="btn btn-info" href="?module=PortForwardGo&a=edit&page=<?php echo $_REQUEST['page']; ?>&id=<?php echo $value->id; ?>"><i class="fas fa-pencil-alt" aria-hidden="true"></i>编辑</a>
										<button type="button" class="btn btn-warning" OnClick="Action('clean',<?php echo $value->id; ?>);"><i class="fas fa-broom" aria-hidden="true"></i>清理</button>
									</td>
								</tr>
							<?php }
						} else { ?>
							<tr id="message">
								<td colspan="8" class="text-center">
									无
								</td>
							</tr>
						<?php } ?>
					</tbody>
				</table>
			</div>
			<div class="text-center">
				<ul class="pagination">
					<?php if ($_REQUEST['pages'] == 1) { ?>
						<li class="previous disabled"><span class="page-selector">« 上一页</span></li>
					<?php } else { ?>
						<li class="previous"><span onClick="window.location.href='addonmodules.php?module=PortForwardGo&page=<?php echo $_REQUEST['page']; ?>&pages=<?php echo $_REQUEST['pages'] - 1; ?><?php echo isset($_REQUEST['id']) ? '&id=' . $_REQUEST['id'] : ""; ?>'" class="page-selector">« 上一页</span></li>
					<?php } ?>
					<?php for ($i = 1; $i <= $count; $i++) {
						if ($i == $_REQUEST['pages']) {
					?>
							<li class="hidden-xs"><span class="page-selector active"><strong><?php echo $i; ?></strong></span></li>
						<?php } else { ?>
							<li class="hidden-xs"><a onClick="window.location.href='addonmodules.php?module=PortForwardGo&page=<?php echo $_REQUEST['page']; ?>&pages=<?php echo $i; ?><?php echo isset($_REQUEST['id']) ? '&id=' . $_REQUEST['id'] : ""; ?>'" class="page-selector"><?php echo $i; ?></a></li>
					<?php }
					} ?>
					<?php if ($count == 0 || $_REQUEST['pages'] == $count) { ?>
						<li class="next disabled"><a class="page-selector">下一页 »</a></li>
					<?php } else { ?>
						<li class="next"><a class="page-selector" onClick="window.location.href='addonmodules.php?module=PortForwardGo&page=<?php echo $_REQUEST['page']; ?>&pages=<?php echo $_REQUEST['pages'] + 1; ?><?php echo isset($_REQUEST['id']) ? '&id=' . $_REQUEST['id'] : ""; ?>'">下一页 »</a></li>
					<?php } ?>
				</ul>
			</div>
		</div>
	</div>
</div>