<br>
<div class="col-xs-12 foot text-center">
        <p>Copyright ZeroTime Team. All Rights Reserved.</p>
        <p> Based On <a href="https://github.com/CoiaPrant/PortForwardGo" style="color: #999;">PortForwardGo</a></p>
        <p><a href="https://shop.zeroteam.top/submitticket.php?step=2&deptid=2" style="color: #999;">Report a Bug</a></p>
</div>