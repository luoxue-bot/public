<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use Illuminate\Database\Capsule\Manager as Capsule;

require_once __DIR__ . '/func.php';

function PortForwardGo_Ajax_force_sync()
{
    $node = Capsule::table('mod_PortForwardGo_Node')->where('id', $_REQUEST['node'])->first();
    if (!$node->api) {
        exit(json_encode(['result' => 'error', 'error' => '节点未开启API主动通知，此功能不可用']));
    }

    $path =  md5(Capsule::table('mod_PortForwardGo_Setting')->where('name', 'key')->first()->value);
    $url = 'http://' . $node->addr . ':' . $node->apiport . '/api/v2/' . $path . '/force_sync';
    if (json_decode(PortForwardGo_httprequest($url), true)['Result']) {
        exit(json_encode(['result' => 'success']));
    } else {
        exit(json_encode(['result' => 'error', 'error' => '未收到节点正确响应，可能是防火墙拦截，授权码错误']));
    }
}
